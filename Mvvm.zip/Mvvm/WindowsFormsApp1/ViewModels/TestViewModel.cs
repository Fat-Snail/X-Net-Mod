﻿using MiniMvvm;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace WindowsFormsApp1.ViewModels
{
    public class TestViewModel : ViewModelBase
    {
        

        public TestViewModel()
        {
            TestNormalCommand = MiniCommand.Create(TestNormal);
            TestAsncCommand = MiniCommand.CreateFromTask(TestAsync);
            TestParamsCommand = MiniCommand.Create<object>(TestParams);
        }

        public ICommand TestAsncCommand { get; }
        private async Task TestAsync()
        {
            Console.WriteLine("The TestAsync Method has call");
        }

        public ICommand TestNormalCommand { get; }
        private void TestNormal()
        {
            Console.WriteLine("The TestNormal Method has call");
        }

        public ICommand TestParamsCommand { get; }
        private void TestParams(object e)
        {
            Console.WriteLine("The TestParams Method has call: " + e.ToString());
        }



        private string _text;
        public string Text
        {
            get => _text;
            set => this.RaiseAndSetIfChanged(ref _text, value);
        }
    }
}
