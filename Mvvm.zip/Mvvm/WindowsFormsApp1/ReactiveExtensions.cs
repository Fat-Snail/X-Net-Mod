﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Linq.Expressions;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Input;

namespace WindowsFormsApp1
{

    internal static class ReactiveExtensions
    {
        public static void Bind<TViewModel, TControl, TProperty>(
            this Form form,
            TViewModel viewModel,
            Expression<Func<TViewModel, TProperty>> viewModelProperty,
            TControl control,
            Expression<Func<TControl, TProperty>> controlProperty,
            bool isOneWay = false)
            where TControl : Control
        {
            Bind(viewModel, viewModelProperty, control, controlProperty);
        }



        public static void OneWayBind<TViewModel, TControl, TProperty>(
            this Form form,
            TViewModel viewModel,
            Expression<Func<TViewModel, TProperty>> viewModelProperty,
            TControl control,
            Expression<Func<TControl, TProperty>> controlProperty)
             where TControl : Control
        {
            Bind(viewModel, viewModelProperty, control, controlProperty, true);
        }

        private static void Bind<TViewModel, TControl, TProperty>(
            TViewModel viewModel,
            Expression<Func<TViewModel, TProperty>> viewModelProperty,
            TControl control,
            Expression<Func<TControl, TProperty>> controlProperty,
            bool isOneWay = false)
            where TControl : Control
        {
            var viewModelPropertyName = ((MemberExpression)viewModelProperty.Body).Member.Name;
            var controlPropertyName = ((MemberExpression)controlProperty.Body).Member.Name;

            var controlPropertyInfo = typeof(TControl).GetProperty(controlPropertyName);

            control.DataBindings.Add(controlPropertyInfo.Name, viewModel, viewModelPropertyName, isOneWay, DataSourceUpdateMode.OnPropertyChanged);
        }

        public static void BindCommand<TViewModel, TControl>(
            this Form form,
            TViewModel viewModel,
            Expression<Func<TViewModel, ICommand>> viewModelProperty,
            TControl control,
            Action<TControl,EventHandler> addEventHandler)
            where TControl : Control
        {
            var viewModelPropertyName = ((MemberExpression)viewModelProperty.Body).Member.Name;

            var viewModelPropertyInfo = typeof(TViewModel).GetProperty(viewModelPropertyName);

            var command = (ICommand)viewModelPropertyInfo.GetValue(viewModel);

            addEventHandler(control, (sender, e) => command.Execute(e));
        }
    }
}
