﻿using MiniMvvm;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1.ViewModels;
using System.Reactive;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private TestViewModel _testVm = new TestViewModel();


        public Form1()
        {
            InitializeComponent();
            //Bind
            //this.textBox1.DataBindings.Add("Text", _testVm, nameof(_testVm.Text), false, DataSourceUpdateMode.OnPropertyChanged);
            ////OneWayBind
            //this.textBox1.DataBindings.Add("Text", _testVm, nameof(_testVm.Text), true, DataSourceUpdateMode.OnPropertyChanged);

            ////优雅一点的写法
            this.Bind(_testVm, vm => vm.Text, textBox1, c => c.Text);
            this.OneWayBind(_testVm, vm => vm.Text, label1, c => c.Text);

            this.BindCommand(_testVm, vm => vm.TestNormalCommand, button1, (c, handler) => c.Click += handler);
            this.BindCommand(_testVm, vm => vm.TestAsncCommand, button1, (c, handler) => c.Click += handler);
            this.BindCommand(_testVm, vm => vm.TestParamsCommand, button1, (c, handler) => c.Click += handler);


            //this.textBox1.TextChanged += TextBox1_TextChanged;


            Task.Run(() =>
            {

                Enumerable.Range(1, 10).ToList().ForEach(x =>
                {
                    this.Invoke(new Action(() =>
                    {
                        _testVm.Text = $"Num:{x}";
                    }));
                    Thread.Sleep(2000);
                });

            });

        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {
            //this.label1.Text = _testVm.Text;

            _testVm.TestAsncCommand.Execute(null);
            _testVm.TestNormalCommand.Execute(null);
            _testVm.TestParamsCommand.Execute("params");
        }

    }
}
