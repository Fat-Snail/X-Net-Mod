﻿// using Avalonia;
//
// namespace AvaloniaApplication1.ViewModels;
//
// public class ViewModelBase: AvaloniaObject  //: ReactiveObject
// {
// }