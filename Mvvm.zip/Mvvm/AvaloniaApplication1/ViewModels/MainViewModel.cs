﻿using System;
using System.Threading.Tasks;
using System.Windows.Input;
using MiniMvvm;

namespace AvaloniaApplication1.ViewModels;

public class MainViewModel : ViewModelBase
{
#pragma warning disable CA1822 // Mark members as static
    public string Greeting => "Mark members as static!";
#pragma warning restore CA1822 // Mark members as static
    
    
    public MainViewModel()
    {

        TestNormalCommand = MiniCommand.Create(TestNormal);
        TestAsncCommand = MiniCommand.CreateFromTask(TestAsync);
        TestParamsCommand = MiniCommand.Create<object>(TestParams);
    }

    public ICommand TestAsncCommand { get; }
    private async Task TestAsync()
    {
        Console.WriteLine("The TestAsync Method has call");
    }

    public ICommand TestNormalCommand { get; }
    private void TestNormal()
    {
        Console.WriteLine("The TestNormal Method has call");
    }

    public ICommand TestParamsCommand { get; }
    private void TestParams(object e)
    {
        Console.WriteLine("The TestParams Method has call: " + e.ToString());
    }



    private string _text="Num:x";
    public string Text
    {
        get => _text;
        set => this.RaiseAndSetIfChanged(ref _text, value);
    }
}