using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Avalonia.Controls;
using Avalonia.Threading;
using AvaloniaApplication1.ViewModels;

namespace AvaloniaApplication1.Views;

public partial class MainView : UserControl
{
    private MainViewModel _viewModel = new MainViewModel();
    public MainView()
    {
        InitializeComponent();
        DataContext = _viewModel;
        
        Task.Run(() =>
        {

            Enumerable.Range(1, 10).ToList().ForEach(x =>
            {
                Dispatcher.UIThread.Invoke(() =>
                {
                    _viewModel.Text = $"Num:{x}";
                });
                Thread.Sleep(2000);
            });

        });
        
    }
}