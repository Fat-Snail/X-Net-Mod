# .NET Aspire 链路追踪示例

本项目演示了如何使用 .NET Aspire 和 OpenTelemetry 实现分布式链路追踪。

## 项目结构

- **AppHost1**: 应用宿主，协调所有服务
- **ApiService**: 后端API服务，提供数据接口
- **WebApp**: 前端Web应用，调用后端API服务

## 链路追踪功能

### 已实现的功能

1. **OpenTelemetry 集成**: 所有服务都已配置 OpenTelemetry 用于链路追踪
2. **分布式追踪**: WebApp → ApiService 的调用链路会被追踪
3. **嵌套追踪**: 支持多层嵌套调用的追踪
4. **控制台输出**: 追踪信息会输出到控制台

### 测试端点

#### WebApp 端点
- `GET /api/tracing/chain` - 分布式链路追踪示例
- `GET /api/tracing/nested` - 嵌套链路追踪示例
- `GET /api/weather` - 调用后端天气API
- `GET /api/hello` - 调用后端Hello API

#### ApiService 端点
- `GET /weatherforecast` - 返回天气预报数据
- `GET /api/hello` - 返回Hello消息

## 如何运行

1. **启动应用宿主**
   ```bash
   cd AppHost1
   dotnet run
   ```

2. **访问服务**
   - WebApp: http://localhost:5000
   - ApiService: http://localhost:5001

3. **测试链路追踪**
   - 访问 http://localhost:5000/api/tracing/chain
   - 访问 http://localhost:5000/api/tracing/nested
   - 观察控制台输出的追踪信息

## 追踪信息示例

在控制台中，你将看到类似以下的追踪信息：

```
Activity.Id:          00-0af7651916bd44384c3f7e4d4e1a4e62-4c7f1875e7a0a449-01
Activity.DisplayName: TracingChain
Activity.Kind:        Internal
Activity.StartTime:   2025-12-05T10:30:15.1234567Z
Activity.Duration:    00:00:00.2345678
Activity.Tags:
    operation.type: distributed_tracing
    service.name: WebApp
    deployment.environment: Development
```

## 技术栈

- **.NET 8.0**: 主要开发框架
- **Aspire**: 微服务编排和依赖管理
- **OpenTelemetry**: 分布式追踪标准
- **ASP.NET Core**: Web框架

## 配置说明

### OpenTelemetry 配置

每个服务都配置了：
- 服务名称和版本
- 环境信息
- ASP.NET Core 和 HTTP 客户端监控
- 控制台输出器

### 服务发现

Aspire 自动处理服务发现，WebApp 可以通过 `http://apiservice` 访问 ApiService。

## 扩展建议

1. **集成 Jaeger 或 Zipkin**: 将追踪数据发送到专门的追踪系统
2. **添加指标监控**: 集成 OpenTelemetry Metrics
3. **日志聚合**: 集成结构化日志和日志聚合系统
4. **告警配置**: 基于追踪数据设置性能告警