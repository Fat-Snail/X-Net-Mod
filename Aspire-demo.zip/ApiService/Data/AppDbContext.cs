using ApiService.Models;
using Microsoft.EntityFrameworkCore;

namespace ApiService.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        public DbSet<Product> Products { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderItem> OrderItems { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // 配置关系
            modelBuilder.Entity<Product>()
                .HasOne(p => p.Category)
                .WithMany(c => c.Products)
                .HasForeignKey(p => p.CategoryId);

            modelBuilder.Entity<OrderItem>()
                .HasOne(oi => oi.Order)
                .WithMany(o => o.OrderItems)
                .HasForeignKey(oi => oi.OrderId);

            modelBuilder.Entity<OrderItem>()
                .HasOne(oi => oi.Product)
                .WithMany(p => p.OrderItems)
                .HasForeignKey(oi => oi.ProductId);

            // 种子数据
            modelBuilder.Entity<Category>().HasData(
                new Category { Id = 1, Name = "电子产品", Description = "电子设备和配件", CreatedAt = DateTime.UtcNow },
                new Category { Id = 2, Name = "服装", Description = "各类服装和配饰", CreatedAt = DateTime.UtcNow },
                new Category { Id = 3, Name = "书籍", Description = "各类图书和出版物", CreatedAt = DateTime.UtcNow }
            );

            modelBuilder.Entity<Product>().HasData(
                new Product { Id = 1, Name = "iPhone 15", Description = "最新款苹果手机", Price = 5999m, CategoryId = 1, CreatedAt = DateTime.UtcNow },
                new Product { Id = 2, Name = "MacBook Pro", Description = "高性能笔记本电脑", Price = 12999m, CategoryId = 1, CreatedAt = DateTime.UtcNow },
                new Product { Id = 3, Name = "T恤", Description = "纯棉T恤", Price = 89m, CategoryId = 2, CreatedAt = DateTime.UtcNow },
                new Product { Id = 4, Name = "C#编程指南", Description = "C#编程学习书籍", Price = 59m, CategoryId = 3, CreatedAt = DateTime.UtcNow }
            );

            modelBuilder.Entity<Order>().HasData(
                new Order { Id = 1, CustomerName = "张三", CustomerEmail = "zhang@example.com", TotalAmount = 6088m, OrderDate = DateTime.UtcNow.AddDays(-5), Status = OrderStatus.Delivered },
                new Order { Id = 2, CustomerName = "李四", CustomerEmail = "li@example.com", TotalAmount = 13058m, OrderDate = DateTime.UtcNow.AddDays(-2), Status = OrderStatus.Processing }
            );

            modelBuilder.Entity<OrderItem>().HasData(
                new OrderItem { Id = 1, OrderId = 1, ProductId = 1, Quantity = 1, UnitPrice = 5999m },
                new OrderItem { Id = 2, OrderId = 1, ProductId = 3, Quantity = 1, UnitPrice = 89m },
                new OrderItem { Id = 3, OrderId = 2, ProductId = 2, Quantity = 1, UnitPrice = 12999m },
                new OrderItem { Id = 4, OrderId = 2, ProductId = 4, Quantity = 1, UnitPrice = 59m }
            );
        }
    }
}