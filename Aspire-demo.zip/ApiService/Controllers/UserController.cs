using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;

namespace ApiService.Controllers;

public class UserController : Controller
{
    
    
    // GET
    public IActionResult Index()
    {
        return Ok();
    }
}