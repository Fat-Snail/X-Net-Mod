using ApiService.Data;
using ApiService.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ApiService.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DataController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly ILogger<DataController> _logger;

        public DataController(AppDbContext context, ILogger<DataController> logger)
        {
            _context = context;
            _logger = logger;
        }

        [HttpGet("dashboard")]
        public async Task<ActionResult> GetDashboardData()
        {
            _logger.LogInformation("获取仪表板数据 - 多表联合查询示例");
            
            // 由于 SQLite 不支持 decimal 类型的聚合操作，需要分别处理
            
            // 获取基础数据用于客户端计算
            var allOrders = await _context.Orders.ToListAsync();
            var todayOrders = allOrders.Where(o => o.OrderDate.Date == DateTime.Today).ToList();
            var orderItems = await _context.OrderItems
                .Include(oi => oi.Product)
                .ToListAsync();

            // 综合仪表板数据：多个表的联合查询
            var dashboardData = new
            {
                // 总销售统计（客户端计算）
                TotalSales = allOrders.Sum(o => o.TotalAmount),
                TotalOrders = allOrders.Count,
                TotalCustomers = allOrders.Select(o => o.CustomerEmail).Distinct().Count(),
                TotalProducts = await _context.Products.CountAsync(),

                // 今日销售（客户端计算）
                TodaySales = todayOrders.Sum(o => o.TotalAmount),

                // 热门产品（客户端计算）
                TopProducts = orderItems
                    .GroupBy(oi => oi.Product.Name)
                    .Select(g => new
                    {
                        ProductName = g.Key,
                        TotalSold = g.Sum(oi => oi.Quantity),
                        TotalRevenue = g.Sum(oi => oi.Quantity * oi.UnitPrice)
                    })
                    .OrderByDescending(p => p.TotalSold)
                    .Take(5)
                    .ToList(),

                // 订单状态分布（可以继续使用数据库聚合）
                OrderStatusDistribution = await _context.Orders
                    .GroupBy(o => o.Status)
                    .Select(g => new
                    {
                        Status = g.Key.ToString(),
                        Count = g.Count()
                    })
                    .ToListAsync(),

                // 最近订单
                RecentOrders = await _context.Orders
                    .Include(o => o.OrderItems)
                        .ThenInclude(oi => oi.Product)
                    .OrderByDescending(o => o.OrderDate)
                    .Take(5)
                    .Select(o => new
                    {
                        o.Id,
                        o.CustomerName,
                        o.TotalAmount,
                        o.OrderDate,
                        o.Status,
                        ItemCount = o.OrderItems.Count
                    })
                    .ToListAsync()
            };

            return Ok(dashboardData);
        }

        [HttpGet("complex-query")]
        public async Task<ActionResult> GetComplexQuery()
        {
            _logger.LogInformation("执行复杂多表联合查询");
            
            // 由于 SQLite 不支持 decimal 类型的聚合操作，先获取数据再在客户端计算
            var deliveredOrders = await (
                from o in _context.Orders
                join oi in _context.OrderItems on o.Id equals oi.OrderId
                join p in _context.Products on oi.ProductId equals p.Id
                join c in _context.Categories on p.CategoryId equals c.Id
                where o.Status == OrderStatus.Delivered
                select new
                {
                    o.CustomerEmail,
                    o.CustomerName,
                    o.Id,
                    o.OrderDate,
                    oi.Quantity,
                    oi.UnitPrice,
                    CategoryName = c.Name
                }
            ).ToListAsync();

            // 在客户端进行分组和聚合计算
            var complexResult = deliveredOrders
                .GroupBy(x => new { x.CustomerEmail, x.CustomerName, x.CategoryName })
                .Select(g => new
                {
                    CustomerEmail = g.Key.CustomerEmail,
                    CustomerName = g.Key.CustomerName,
                    CategoryName = g.Key.CategoryName,
                    TotalSpentInCategory = g.Sum(x => x.Quantity * x.UnitPrice),
                    TotalItemsInCategory = g.Sum(x => x.Quantity),
                    OrderCount = g.Select(x => x.Id).Distinct().Count(),
                    LastPurchaseDate = g.Max(x => x.OrderDate)
                })
                .OrderByDescending(x => x.TotalSpentInCategory)
                .ToList();

            return Ok(complexResult);
        }

        [HttpGet("sales-trend")]
        public async Task<ActionResult> GetSalesTrend()
        {
            _logger.LogInformation("获取销售趋势数据");
            
            // 由于 SQLite 不支持 decimal 类型的聚合操作，先获取数据再在客户端计算
            var orders = await _context.Orders
                .Include(o => o.OrderItems)
                .Select(o => new
                {
                    o.OrderDate,
                    o.TotalAmount,
                    OrderItems = o.OrderItems.Select(oi => new { oi.Quantity }).ToList()
                })
                .ToListAsync();

            // 在客户端进行分组和聚合计算
            var salesTrend = orders
                .GroupBy(o => o.OrderDate.Date)
                .Select(g => new
                {
                    Date = g.Key,
                    TotalSales = g.Sum(o => o.TotalAmount),
                    OrderCount = g.Count(),
                    AverageOrderValue = g.Average(o => o.TotalAmount),
                    ProductsSold = g.SelectMany(o => o.OrderItems).Sum(oi => oi.Quantity)
                })
                .OrderBy(s => s.Date)
                .ToList();

            return Ok(salesTrend);
        }
    }
}