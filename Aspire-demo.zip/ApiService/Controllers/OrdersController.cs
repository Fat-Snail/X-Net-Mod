using ApiService.Data;
using ApiService.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ApiService.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrdersController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly ILogger<OrdersController> _logger;

        public OrdersController(AppDbContext context, ILogger<OrdersController> logger)
        {
            _context = context;
            _logger = logger;
        }

        [HttpGet]
        public async Task<ActionResult> GetOrders()
        {
            _logger.LogInformation("获取所有订单列表");
            
            // 多表联合查询示例：订单 + 订单项 + 产品 + 分类
            var orders = await _context.Orders
                .Include(o => o.OrderItems)
                    .ThenInclude(oi => oi.Product)
                        .ThenInclude(p => p.Category)
                .Select(o => new
                {
                    o.Id,
                    o.CustomerName,
                    o.CustomerEmail,
                    o.TotalAmount,
                    o.OrderDate,
                    o.Status,
                    OrderItems = o.OrderItems.Select(oi => new
                    {
                        oi.Id,
                        ProductName = oi.Product.Name,
                        ProductCategory = oi.Product.Category.Name,
                        oi.Quantity,
                        oi.UnitPrice,
                        TotalPrice = oi.Quantity * oi.UnitPrice
                    })
                })
                .OrderByDescending(o => o.OrderDate)
                .ToListAsync();

            return Ok(orders);
        }

        [HttpGet("category-stats")]
        public async Task<ActionResult> GetCategoryStatistics()
        {
            _logger.LogInformation("获取分类销售统计");
            
            // 由于 SQLite 不支持 decimal 类型的聚合操作，先获取数据再在客户端计算
            var orderItems = await _context.OrderItems
                .Include(oi => oi.Product)
                    .ThenInclude(p => p.Category)
                .Select(oi => new
                {
                    oi.OrderId,
                    oi.Quantity,
                    oi.UnitPrice,
                    CategoryName = oi.Product.Category.Name
                })
                .ToListAsync();

            // 在客户端进行分组和聚合计算
            var stats = orderItems
                .GroupBy(oi => oi.CategoryName)
                .Select(g => new
                {
                    CategoryName = g.Key,
                    TotalSales = g.Sum(oi => oi.Quantity * oi.UnitPrice),
                    TotalQuantity = g.Sum(oi => oi.Quantity),
                    OrderCount = g.Select(oi => oi.OrderId).Distinct().Count()
                })
                .OrderByDescending(s => s.TotalSales)
                .ToList();

            return Ok(stats);
        }

        [HttpGet("customer-summary")]
        public async Task<ActionResult> GetCustomerSummary()
        {
            _logger.LogInformation("获取客户购买统计");
            
            // 由于 SQLite 不支持 decimal 类型的聚合操作，先获取数据再在客户端计算
            var orders = await _context.Orders
                .Include(o => o.OrderItems)
                    .ThenInclude(oi => oi.Product)
                .Select(o => new
                {
                    o.CustomerEmail,
                    o.CustomerName,
                    o.TotalAmount,
                    o.OrderDate,
                    OrderItems = o.OrderItems.Select(oi => new 
                    { 
                        oi.Quantity, 
                        CategoryName = oi.Product.Category.Name 
                    }).ToList()
                })
                .ToListAsync();

            // 在客户端进行分组和聚合计算
            var customerSummary = orders
                .GroupBy(o => o.CustomerEmail)
                .Select(g => new
                {
                    CustomerEmail = g.Key,
                    CustomerName = g.First().CustomerName,
                    TotalOrders = g.Count(),
                    TotalSpent = g.Sum(o => o.TotalAmount),
                    LastOrderDate = g.Max(o => o.OrderDate),
                    FavoriteCategory = g.SelectMany(o => o.OrderItems)
                        .GroupBy(oi => oi.CategoryName)
                        .OrderByDescending(cat => cat.Sum(oi => oi.Quantity))
                        .Select(cat => cat.Key)
                        .FirstOrDefault()
                })
                .OrderByDescending(c => c.TotalSpent)
                .ToList();

            return Ok(customerSummary);
        }

        [HttpGet("product-performance")]
        public async Task<ActionResult> GetProductPerformance()
        {
            _logger.LogInformation("获取产品销售性能分析");
            
            // 由于 SQLite 不支持 decimal 类型的聚合操作，先获取数据再在客户端计算
            var products = await _context.Products
                .Include(p => p.Category)
                .Include(p => p.OrderItems)
                .Select(p => new
                {
                    p.Id,
                    p.Name,
                    Category = p.Category.Name,
                    p.Price,
                    OrderItems = p.OrderItems.Select(oi => new 
                    { 
                        oi.Quantity, 
                        oi.UnitPrice,
                        oi.OrderId 
                    }).ToList()
                })
                .ToListAsync();

            // 在客户端进行聚合计算
            var productPerformance = products
                .Select(p => new
                {
                    p.Id,
                    p.Name,
                    p.Category,
                    p.Price,
                    TotalSold = p.OrderItems.Sum(oi => oi.Quantity),
                    TotalRevenue = p.OrderItems.Sum(oi => oi.Quantity * oi.UnitPrice),
                    OrderCount = p.OrderItems.Select(oi => oi.OrderId).Distinct().Count(),
                    AvgOrderQuantity = p.OrderItems.Any() ? 
                        p.OrderItems.Average(oi => oi.Quantity) : 0
                })
                .OrderByDescending(p => p.TotalRevenue)
                .ToList();

            return Ok(productPerformance);
        }
    }
}