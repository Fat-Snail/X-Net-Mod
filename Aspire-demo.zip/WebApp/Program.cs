
using OctopusEx.WebCore.Extensions;
//using WebApp.Extensions;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
//builder.AddServiceDefaults();
builder.AddAspireOpenTelemetry();
//builder.Services.AddSingleton<TelemetryService>();
builder.Services.AddRazorPages();
builder.Services.AddControllers();

// Add HttpClient for API calls
builder.Services.AddHttpClient("ApiService", client =>
{
    // The URL will be resolved by Aspire's service discovery
    // In development, we can use localhost with explicit port
    client.BaseAddress = new Uri("http://localhost:5000");
});



var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHttpsRedirection();
}



app.UseStaticFiles();
app.UseRouting();

app.MapRazorPages();

// 添加API控制器路由
app.MapControllers();

// 添加API控制器路由
app.MapControllers();

// Example API endpoint that calls the backend API service
app.MapGet("/api/weather", async (IHttpClientFactory httpClientFactory) =>
{
    try
    {
        var client = httpClientFactory.CreateClient("ApiService");
        var response = await client.GetAsync("/weatherforecast");
        response.EnsureSuccessStatusCode();
        var content = await response.Content.ReadAsStringAsync();
        return Results.Content(content, "application/json");
    }
    catch (Exception ex)
    {
        return Results.Problem($"Error calling API service: {ex.Message}");
    }
});

app.MapGet("/api/hello", async (IHttpClientFactory httpClientFactory) =>
{
    try
    {
        var client = httpClientFactory.CreateClient("ApiService");
        var response = await client.GetAsync("/api/hello");
        response.EnsureSuccessStatusCode();
        var content = await response.Content.ReadAsStringAsync();
        return Results.Content(content, "application/json");
    }
    catch (Exception ex)
    {
        return Results.Problem($"Error calling API service: {ex.Message}");
    }
});

app.MapGet("/", () => "WebApp is running!");

app.Run();