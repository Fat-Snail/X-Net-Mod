using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
//using WebApp.Services;

namespace WebApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TracingController : ControllerBase
    {
        private static readonly ActivitySource ActivitySource = new ActivitySource("WebApp.TracingController");
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly ILogger<TracingController> _logger;
        //private TelemetryService _telemetry;

        public TracingController(IHttpClientFactory httpClientFactory, ILogger<TracingController> logger)
        {
            _httpClientFactory = httpClientFactory;
            _logger = logger;
            //_telemetry = telemetry;
        }

        // private static readonly string[] Summaries = new[]
        // {
        //     "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        // };
        // /// <summary>
        // /// Gets weather forecast for specified number of days
        // /// </summary>
        // /// <param name="days">Number of days to forecast (1-30)</param>
        // /// <returns>Array of weather forecasts</returns>
        // /// <response code="200">Returns the weather forecast</response>
        // /// <response code="400">If days parameter is invalid</response>
        // [HttpGet("cast")]
        // [ProducesResponseType(typeof(IEnumerable<WeatherForecast>), StatusCodes.Status200OK)]
        // [ProducesResponseType(StatusCodes.Status400BadRequest)]
        // public IEnumerable<WeatherForecast> Get()
        // {
        //     var days = Random.Shared.Next(1, 30);
        //     using var activity = _telemetry.ActivitySource.StartActivity("GetWeatherForecast");
        //     activity?.SetTag("forecast.days", days);
        //     _logger.LogInformation("Generating weather forecast for {Days} days", days);
        //     _telemetry.RequestCounter.Add(1,
        //         new KeyValuePair<string, object?>("endpoint", "get_forecast"),
        //         new KeyValuePair<string, object?>("days", days.ToString()));
        //
        //     var stopwatch = Stopwatch.StartNew();
        //     try
        //     {
        //         if (days < 1 || days > 30)
        //         {
        //             _logger.LogWarning("Invalid number of days requested: {Days}", days);
        //             activity?.SetStatus(ActivityStatusCode.Error, "Invalid number of days");
        //             throw new ArgumentException("Days must be between 1 and 30");
        //         }
        //
        //         var forecasts = Enumerable.Range(1, days).Select(index => new WeatherForecast
        //             {
        //                 Date = DateOnly.FromDateTime(DateTime.Now.AddDays(index)),
        //                 TemperatureC = Random.Shared.Next(-20, 55),
        //                 Summary = Summaries[Random.Shared.Next(Summaries.Length)]
        //             })
        //             .ToArray();
        //
        //         _logger.LogInformation("Successfully generated {Count} weather forecasts", forecasts.Length);
        //         activity?.SetTag("forecast.count", forecasts.Length);
        //         return forecasts;
        //     }
        //     finally
        //     {
        //         stopwatch.Stop();
        //         _telemetry.RequestDuration.Record(stopwatch.ElapsedMilliseconds,
        //             new KeyValuePair<string, object?>("endpoint", "get_forecast"));
        //     }
        // }

        [HttpGet("chain")]
        public async Task<IActionResult> GetTracingChain()
        {
            using var activity = ActivitySource.StartActivity("TracingChain");
            activity?.SetTag("operation.type", "distributed_tracing");

            _logger.LogInformation("开始分布式链路追踪示例");

            var result = new
            {
                WebApp = "WebApp 服务开始处理请求",
                Timestamp = DateTime.UtcNow,
                TraceId = Activity.Current?.TraceId.ToString() ?? "N/A",
                SpanId = Activity.Current?.SpanId.ToString() ?? "N/A"
            };

            // 模拟一些处理逻辑
            await SimulateProcessing();

            // 调用ApiService
            var apiResult = await CallApiService();

            _logger.LogInformation("分布式链路追踪完成，TraceId: {TraceId}", result.TraceId);

            return Ok(new
            {
                WebAppResult = result,
                ApiServiceResult = apiResult,
                Message = "链路追踪示例完成"
            });
        }

        [HttpGet("nested")]
        public async Task<IActionResult> GetNestedTracing()
        {
            using var activity = ActivitySource.StartActivity("NestedTracing");
            activity?.SetTag("operation.type", "nested_tracing");
            activity?.SetTag("nested.level", "1");

            _logger.LogInformation("开始嵌套链路追踪示例 - 第一层");

            var results = new List<object>
            {
                new { Level = 1, Service = "WebApp", Timestamp = DateTime.UtcNow }
            };

            // 第一层嵌套调用
            await NestedCall(2);

            // 调用ApiService
            var apiResult = await CallApiService();
            results.Add(apiResult);

            return Ok(new
            {
                Results = results,
                TraceId = Activity.Current?.TraceId.ToString() ?? "N/A",
                Message = "嵌套链路追踪完成"
            });
        }

        private async Task NestedCall(int level)
        {
            using var activity = ActivitySource.StartActivity($"NestedCall-Level{level}");
            activity?.SetTag("nested.level", level.ToString());

            _logger.LogInformation("嵌套调用 - 第{Level}层", level);

            await Task.Delay(100); // 模拟处理时间

            if (level < 3)
            {
                await NestedCall(level + 1);
            }
        }

        private async Task SimulateProcessing()
        {
            using var activity = ActivitySource.StartActivity("SimulateProcessing");
            activity?.SetTag("processing.type", "simulation");

            _logger.LogInformation("模拟处理逻辑开始");

            // 模拟一些处理步骤
            await Task.Delay(50);

            using (var stepActivity = ActivitySource.StartActivity("ProcessingStep1"))
            {
                stepActivity?.SetTag("step.name", "数据验证");
                await Task.Delay(30);
            }

            using (var stepActivity = ActivitySource.StartActivity("ProcessingStep2"))
            {
                stepActivity?.SetTag("step.name", "业务逻辑处理");
                await Task.Delay(40);
            }

            _logger.LogInformation("模拟处理逻辑完成");
        }

        private async Task<object> CallApiService()
        {
            using var activity = ActivitySource.StartActivity("CallApiService");
            activity?.SetTag("service.target", "ApiService");
            activity?.SetTag("http.method", "GET");

            try
            {
                var client = _httpClientFactory.CreateClient("ApiService");

                _logger.LogInformation("开始调用ApiService");

                // 调用多个API端点来展示链路追踪
                var tasks = new List<Task<HttpResponseMessage>>
                {
                    client.GetAsync("/weatherforecast"),
                    client.GetAsync("/api/hello")
                };

                await Task.WhenAll(tasks);

                var responses = await Task.WhenAll(tasks.Select(t => t.Result.Content.ReadAsStringAsync()));

                _logger.LogInformation("ApiService调用成功");

                return new
                {
                    Service = "ApiService",
                    Timestamp = DateTime.UtcNow,
                    WeatherForecast = responses[0],
                    HelloMessage = responses[1],
                    Success = true
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "调用ApiService时发生错误");
                activity?.SetTag("error", true);
                activity?.SetTag("error.message", ex.Message);

                return new
                {
                    Service = "ApiService",
                    Timestamp = DateTime.UtcNow,
                    Error = ex.Message,
                    Success = false
                };
            }
        }
    }
    
    public class WeatherForecast
    {
        public DateOnly Date { get; set; }

        public int TemperatureC { get; set; }

        public int TemperatureF => 32 + (int)(TemperatureC / 0.5556);

        public string? Summary { get; set; }
    }
}