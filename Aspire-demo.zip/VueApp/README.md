# Vue 3 前端应用

这是一个与 .NET Aspire 集成的 Vue 3 前端应用。

## 功能特性

- Vue 3 + Vite 构建
- 与 .NET Aspire 后端服务集成
- 实时服务状态监控
- 响应式设计

## 开发环境

### 前置要求

- Node.js 16+
- npm 或 yarn

### 安装依赖

```bash
cd VueApp
npm install
```

### 启动开发服务器

```bash
npm run dev
```

或者使用集成启动脚本：

```bash
node start-vue.js
```

应用将在 http://localhost:3000 启动

## 与 .NET Aspire 集成

Vue 应用通过以下方式与后端服务集成：

1. **API 代理**: 通过 Vite 代理配置，将 `/api` 请求转发到 WebApp 服务
2. **服务发现**: 在 Aspire 环境中自动发现后端服务端点
3. **状态监控**: 实时监控 API 服务和 WebApp 服务的在线状态

## 项目结构

```
VueApp/
├── src/
│   ├── App.vue          # 主应用组件
│   ├── main.js          # 应用入口
│   └── style.css        # 全局样式
├── package.json         # 项目配置
├── vite.config.js       # Vite 配置
├── index.html           # HTML 模板
└── start-vue.js         # 启动脚本
```

## API 端点

- `/api/hello` - 获取问候语
- `/api/weather` - 获取天气预报数据

## 构建生产版本

```bash
npm run build
```

构建产物将输出到 `dist/` 目录。