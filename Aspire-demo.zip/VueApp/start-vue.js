const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

// 检查 package.json 是否存在
if (!fs.existsSync(path.join(__dirname, 'package.json'))) {
  console.error('错误: package.json 不存在，请确保 Vue 项目已正确创建');
  process.exit(1);
}

console.log('正在启动 Vue 3 开发服务器...');

// 安装依赖（如果 node_modules 不存在）
if (!fs.existsSync(path.join(__dirname, 'node_modules'))) {
  console.log('首次运行，正在安装依赖...');
  const install = spawn('npm', ['install'], { 
    cwd: __dirname, 
    stdio: 'inherit',
    shell: true
  });

  install.on('close', (code) => {
    if (code === 0) {
      startDevServer();
    } else {
      console.error('依赖安装失败');
      process.exit(1);
    }
  });
} else {
  startDevServer();
}

function startDevServer() {
  const devServer = spawn('npm', ['run', 'dev'], { 
    cwd: __dirname, 
    stdio: 'inherit',
    shell: true
  });

  devServer.on('close', (code) => {
    console.log(`Vue 开发服务器已退出，代码: ${code}`);
  });

  // 优雅退出
  process.on('SIGINT', () => {
    console.log('正在关闭 Vue 开发服务器...');
    devServer.kill('SIGINT');
  });
}