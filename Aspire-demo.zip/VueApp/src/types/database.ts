// 产品类型定义
export interface Product {
  id: number
  name: string
  description: string
  price: number
  categoryId: number
  createdAt: string
  category?: Category
}

// 分类类型定义
export interface Category {
  id: number
  name: string
  description: string
  createdAt: string
}

// 订单类型定义
export interface Order {
  id: number
  customerName: string
  customerEmail: string
  totalAmount: number
  orderDate: string
  status: OrderStatus
  orderItems: OrderItem[]
}

export enum OrderStatus {
  Pending = 'Pending',
  Processing = 'Processing',
  Shipped = 'Shipped',
  Delivered = 'Delivered',
  Cancelled = 'Cancelled'
}

// 订单项类型定义
export interface OrderItem {
  id: number
  orderId: number
  productId: number
  quantity: number
  unitPrice: number
  product?: Product
}

// 分类统计类型定义
export interface CategoryStats {
  categoryName: string
  totalSales: number
  totalQuantity: number
  orderCount: number
}

// 客户摘要类型定义
export interface CustomerSummary {
  customerEmail: string
  customerName: string
  totalOrders: number
  totalSpent: number
  lastOrderDate: string
  favoriteCategory?: string
}

// 产品性能类型定义
export interface ProductPerformance {
  id: number
  name: string
  category: string
  price: number
  totalSold: number
  totalRevenue: number
  orderCount: number
  avgOrderQuantity: number
}

// 仪表板数据类型定义
export interface DashboardData {
  totalSales: number
  totalOrders: number
  totalCustomers: number
  totalProducts: number
  todaySales: number
  topProducts: Array<{
    productName: string
    totalSold: number
    totalRevenue: number
  }>
  orderStatusDistribution: Array<{
    status: string
    count: number
  }>
  recentOrders: Array<{
    id: number
    customerName: string
    totalAmount: number
    orderDate: string
    status: OrderStatus
    itemCount: number
  }>
}

// 销售趋势类型定义
export interface SalesTrend {
  date: string
  totalSales: number
  orderCount: number
  averageOrderValue: number
  productsSold: number
}