<template>
  <div class="container">
    <header class="header">
      <h1>Vue 3 + .NET Aspire 集成演示</h1>
      <p>使用 Vue 3 前端与 .NET Aspire 后端服务交互</p>
    </header>

    <main>
      <!-- 数据库查询演示 -->
      <DatabaseQuery />

      <div class="card">
        <h2>基础 API 测试</h2>
        <div class="button-group">
          <button @click="fetchHello" class="button" :disabled="loading">
            {{ loading ? '请求中...' : '获取问候语' }}
          </button>
          <button @click="fetchWeather" class="button" :disabled="loading">
            {{ loading ? '请求中...' : '获取天气数据' }}
          </button>
        </div>

        <div v-if="error" class="error">
          {{ error }}
        </div>

        <div v-if="helloMessage" class="card">
          <h3>API 响应：</h3>
          <p>{{ helloMessage }}</p>
        </div>

        <div v-if="weatherData.length > 0" class="card">
          <h3>天气预报：</h3>
          <div class="weather-grid">
            <div v-for="day in weatherData" :key="day.date" class="weather-item">
              <h4>{{ formatDate(day.date) }}</h4>
              <p><strong>温度：</strong>{{ day.temperatureC }}°C / {{ day.temperatureF }}°F</p>
              <p><strong>天气：</strong>{{ day.summary }}</p>
            </div>
          </div>
        </div>

        <div v-if="loading" class="loading">
          正在请求数据...
        </div>
      </div>

      <div class="card">
        <h2>服务状态</h2>
        <div class="status-grid">
          <div class="status-item">
            <span class="status-indicator" :class="{ online: apiServiceOnline }"></span>
            <span>API 服务: {{ apiServiceOnline ? '在线' : '离线' }}</span>
          </div>
          <div class="status-item">
            <span class="status-indicator" :class="{ online: webAppOnline }"></span>
            <span>WebApp 服务: {{ webAppOnline ? '在线' : '离线' }}</span>
          </div>
        </div>
      </div>
    </main>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import axios from 'axios'
import DatabaseQuery from './components/DatabaseQuery.vue'
import type { WeatherForecast } from './types/weather'

const loading = ref<boolean>(false)
const error = ref<string>('')
const helloMessage = ref<string>('')
const weatherData = ref<WeatherForecast[]>([])
const apiServiceOnline = ref<boolean>(false)
const webAppOnline = ref<boolean>(false)

const fetchHello = async (): Promise<void> => {
  loading.value = true
  error.value = ''
  helloMessage.value = ''
  
  try {
    const response = await axios.get('/webapi/hello')
    helloMessage.value = response.data
    webAppOnline.value = true
  } catch (err: any) {
    error.value = `获取问候语失败: ${err.message}`
    webAppOnline.value = false
  } finally {
    loading.value = false
  }
}

const fetchWeather = async (): Promise<void> => {
  loading.value = true
  error.value = ''
  weatherData.value = []
  
  try {
    const response = await axios.get<WeatherForecast[]>('/webapi/weather')
    weatherData.value = response.data
    webAppOnline.value = true
  } catch (err: any) {
    error.value = `获取天气数据失败: ${err.message}`
    webAppOnline.value = false
  } finally {
    loading.value = false
  }
}

const formatDate = (dateString: string): string => {
  return new Date(dateString).toLocaleDateString('zh-CN', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  })
}

const checkServiceStatus = async (): Promise<void> => {
  try {
    // 检查 WebApp 服务状态
    await axios.get('/webapi/hello', { timeout: 2000 })
    webAppOnline.value = true
  } catch {
    webAppOnline.value = false
  }
}

onMounted(() => {
  checkServiceStatus()
  // 每30秒检查一次服务状态
  setInterval(checkServiceStatus, 30000)
})
</script>

<style scoped>
.button-group {
  display: flex;
  gap: 1rem;
  margin: 1rem 0;
}

.status-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1rem;
}

.status-item {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.status-indicator {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background-color: #ccc;
}

.status-indicator.online {
  background-color: #4CAF50;
}

.status-indicator.offline {
  background-color: #f44336;
}
</style>