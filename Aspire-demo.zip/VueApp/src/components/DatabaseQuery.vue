<template>
  <div class="database-container">
    <h2>数据库查询演示</h2>
    <p>使用 EFCore + SQLite 的多表联合查询示例</p>

    <!-- 查询按钮组 -->
    <div class="button-group">
      <button @click="fetchProducts" class="button" :disabled="loading">
        {{ loading && activeTab === 'products' ? '加载中...' : '获取产品列表' }}
      </button>
      <button @click="fetchOrders" class="button" :disabled="loading">
        {{ loading && activeTab === 'orders' ? '加载中...' : '获取订单详情' }}
      </button>
      <button @click="fetchCategoryStats" class="button" :disabled="loading">
        {{ loading && activeTab === 'category-stats' ? '加载中...' : '分类销售统计' }}
      </button>
      <button @click="fetchDashboard" class="button" :disabled="loading">
        {{ loading && activeTab === 'dashboard' ? '加载中...' : '仪表板数据' }}
      </button>
      <button @click="fetchSalesTrend" class="button" :disabled="loading">
        {{ loading && activeTab === 'sales-trend' ? '加载中...' : '销售趋势' }}
      </button>
    </div>

    <!-- 错误信息 -->
    <div v-if="error" class="error">
      {{ error }}
    </div>

    <!-- 产品列表 -->
    <div v-if="activeTab === 'products' && products.length > 0" class="data-section">
      <h3>产品列表 ({{ products.length }})</h3>
      <div class="product-grid">
        <div v-for="product in products" :key="product.id" class="product-card">
          <h4>{{ product.name }}</h4>
          <p class="description">{{ product.description }}</p>
          <p class="price">¥{{ product.price.toFixed(2) }}</p>
          <p class="category">分类: {{ product.category?.name || '未分类' }}</p>
          <p class="created">创建时间: {{ formatDate(product.createdAt) }}</p>
        </div>
      </div>
    </div>

    <!-- 订单详情 -->
    <div v-if="activeTab === 'orders' && orders.length > 0" class="data-section">
      <h3>订单列表 ({{ orders.length }})</h3>
      <div class="order-grid">
        <div v-for="order in orders" :key="order.id" class="order-card">
          <div class="order-header">
            <h4>订单 #{{ order.id }}</h4>
            <span class="status" :class="String(order.status).toLowerCase()">{{ order.status }}</span>
          </div>
          <p><strong>客户:</strong> {{ order.customerName }} ({{ order.customerEmail }})</p>
          <p><strong>总金额:</strong> ¥{{ order.totalAmount.toFixed(2) }}</p>
          <p><strong>下单时间:</strong> {{ formatDate(order.orderDate) }}</p>
          
          <div class="order-items">
            <h5>订单项:</h5>
            <div v-for="item in order.orderItems" :key="item.id" class="order-item">
              <span>{{ item.productName }}</span>
              <span>×{{ item.quantity }}</span>
              <span>¥{{ item.totalPrice.toFixed(2) }}</span>
              <span class="category">{{ item.productCategory }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 分类统计 -->
    <div v-if="activeTab === 'category-stats' && categoryStats.length > 0" class="data-section">
      <h3>分类销售统计</h3>
      <div class="stats-grid">
        <div v-for="stat in categoryStats" :key="stat.categoryName" class="stat-card">
          <h4>{{ stat.categoryName }}</h4>
          <p class="total-sales">销售额: ¥{{ stat.totalSales.toFixed(2) }}</p>
          <p class="quantity">销售量: {{ stat.totalQuantity }}</p>
          <p class="orders">订单数: {{ stat.orderCount }}</p>
        </div>
      </div>
    </div>

    <!-- 仪表板数据 -->
    <div v-if="activeTab === 'dashboard' && dashboardData" class="data-section">
      <h3>仪表板数据</h3>
      
      <!-- 关键指标 -->
      <div class="metrics-grid">
        <div class="metric-card">
          <h4>总销售额</h4>
          <p class="value">¥{{ dashboardData.totalSales.toFixed(2) }}</p>
        </div>
        <div class="metric-card">
          <h4>总订单数</h4>
          <p class="value">{{ dashboardData.totalOrders }}</p>
        </div>
        <div class="metric-card">
          <h4>客户数量</h4>
          <p class="value">{{ dashboardData.totalCustomers }}</p>
        </div>
        <div class="metric-card">
          <h4>产品数量</h4>
          <p class="value">{{ dashboardData.totalProducts }}</p>
        </div>
        <div class="metric-card">
          <h4>今日销售额</h4>
          <p class="value">¥{{ dashboardData.todaySales.toFixed(2) }}</p>
        </div>
      </div>

      <!-- 热门产品 -->
      <div class="top-products">
        <h4>热门产品</h4>
        <div v-for="product in dashboardData.topProducts" :key="product.productName" class="product-row">
          <span>{{ product.productName }}</span>
          <span>销量: {{ product.totalSold }}</span>
          <span>收入: ¥{{ product.totalRevenue.toFixed(2) }}</span>
        </div>
      </div>

      <!-- 最近订单 -->
      <div class="recent-orders">
        <h4>最近订单</h4>
        <div v-for="order in dashboardData.recentOrders" :key="order.id" class="order-row">
          <span>{{ order.customerName }}</span>
          <span>¥{{ order.totalAmount.toFixed(2) }}</span>
          <span>{{ formatDate(order.orderDate) }}</span>
          <span :class="String(order.status).toLowerCase()">{{ order.status }}</span>
        </div>
      </div>
    </div>

    <!-- 销售趋势 -->
    <div v-if="activeTab === 'sales-trend' && salesTrend.length > 0" class="data-section">
      <h3>销售趋势</h3>
      <div class="trend-grid">
        <div v-for="trend in salesTrend" :key="trend.date" class="trend-card">
          <h4>{{ formatDate(trend.date) }}</h4>
          <p class="sales">销售额: ¥{{ trend.totalSales.toFixed(2) }}</p>
          <p class="orders">订单数: {{ trend.orderCount }}</p>
          <p class="avg">平均订单值: ¥{{ trend.averageOrderValue.toFixed(2) }}</p>
          <p class="products">售出产品: {{ trend.productsSold }}</p>
        </div>
      </div>
    </div>

    <!-- 加载状态 -->
    <div v-if="loading" class="loading">
      正在加载数据...
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import axios from 'axios'
import type { 
  Product, 
  CategoryStats, 
  DashboardData, 
  SalesTrend 
} from '../types/database'

const loading = ref<boolean>(false)
const error = ref<string>('')
const activeTab = ref<string>('')

// 数据状态
const products = ref<Product[]>([])
const orders = ref<any[]>([])
const categoryStats = ref<CategoryStats[]>([])
const dashboardData = ref<DashboardData | null>(null)
const salesTrend = ref<SalesTrend[]>([])

// API调用函数
const fetchProducts = async (): Promise<void> => {
  loading.value = true
  error.value = ''
  activeTab.value = 'products'
  
  try {
    const response = await axios.get('/orderapi/products')
    products.value = response.data
  } catch (err: any) {
    error.value = `获取产品列表失败: ${err.message}`
    products.value = []
  } finally {
    loading.value = false
  }
}

const fetchOrders = async (): Promise<void> => {
  loading.value = true
  error.value = ''
  activeTab.value = 'orders'
  
  try {
    const response = await axios.get('/orderapi/orders')
    orders.value = response.data
  } catch (err: any) {
    error.value = `获取订单列表失败: ${err.message}`
    orders.value = []
  } finally {
    loading.value = false
  }
}

const fetchCategoryStats = async (): Promise<void> => {
  loading.value = true
  error.value = ''
  activeTab.value = 'category-stats'
  
  try {
    const response = await axios.get('/orderapi/orders/category-stats')
    categoryStats.value = response.data
  } catch (err: any) {
    error.value = `获取分类统计失败: ${err.message}`
    categoryStats.value = []
  } finally {
    loading.value = false
  }
}

const fetchDashboard = async (): Promise<void> => {
  loading.value = true
  error.value = ''
  activeTab.value = 'dashboard'
  
  try {
    const response = await axios.get('/orderapi/data/dashboard')
    dashboardData.value = response.data
  } catch (err: any) {
    error.value = `获取仪表板数据失败: ${err.message}`
    dashboardData.value = null
  } finally {
    loading.value = false
  }
}

const fetchSalesTrend = async (): Promise<void> => {
  loading.value = true
  error.value = ''
  activeTab.value = 'sales-trend'
  
  try {
    const response = await axios.get('/orderapi/data/sales-trend')
    salesTrend.value = response.data
  } catch (err: any) {
    error.value = `获取销售趋势失败: ${err.message}`
    salesTrend.value = []
  } finally {
    loading.value = false
  }
}

const formatDate = (dateString: string): string => {
  return new Date(dateString).toLocaleDateString('zh-CN', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  })
}
</script>

<style scoped>
.database-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 1rem;
}

.button-group {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
  margin: 1rem 0;
}

.data-section {
  margin-top: 2rem;
}

/* 产品网格样式 */
.product-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 1rem;
}

.product-card {
  border: 1px solid #ddd;
  border-radius: 8px;
  padding: 1rem;
  background: white;
}

.product-card h4 {
  margin: 0 0 0.5rem 0;
  color: #333;
}

.product-card .price {
  font-weight: bold;
  color: #e74c3c;
  font-size: 1.2em;
}

.product-card .category {
  color: #666;
  font-size: 0.9em;
}

/* 订单网格样式 */
.order-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(400px, 1fr));
  gap: 1rem;
}

.order-card {
  border: 1px solid #ddd;
  border-radius: 8px;
  padding: 1rem;
  background: white;
}

.order-header {
  display: flex;
  justify-content: between;
  align-items: center;
  margin-bottom: 0.5rem;
}

.status {
  padding: 0.2rem 0.5rem;
  border-radius: 4px;
  font-size: 0.8em;
  font-weight: bold;
}

.status.delivered { background: #d4edda; color: #155724; }
.status.processing { background: #fff3cd; color: #856404; }
.status.pending { background: #f8d7da; color: #721c24; }

.order-items {
  margin-top: 0.5rem;
}

.order-item {
  display: flex;
  justify-content: space-between;
  padding: 0.2rem 0;
  border-bottom: 1px solid #eee;
}

/* 统计网格样式 */
.stats-grid, .metrics-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  gap: 1rem;
}

.stat-card, .metric-card {
  border: 1px solid #ddd;
  border-radius: 8px;
  padding: 1rem;
  background: white;
  text-align: center;
}

.metric-card .value {
  font-size: 2em;
  font-weight: bold;
  color: #3498db;
  margin: 0;
}

/* 加载和错误样式 */
.loading {
  text-align: center;
  padding: 2rem;
  color: #666;
}

.error {
  background: #f8d7da;
  color: #721c24;
  padding: 0.75rem;
  border-radius: 4px;
  margin: 1rem 0;
}
</style>