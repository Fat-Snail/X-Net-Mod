var builder = DistributedApplication.CreateBuilder(args);

// 添加API服务
var apiService = builder.AddProject<Projects.ApiService>("apiservice");

// 添加Web应用，并配置依赖关系
var webApp = builder.AddProject<Projects.WebApp>("webapp")
    .WithReference(apiService);

// // 使用 AddExecutable 添加 Vue 前端应用
// var vueApp = builder.AddExecutable("vueapp", "npm", workingDirectory: "../VueApp")
//     .WithArgs("run", "dev")
//     .WithReference(webApp)
//     .WithEnvironment("VITE_API_URL", webApp.GetEndpoint("http"))
//     .WaitFor(webApp);

var vueApp = builder.AddNpmApp("vueapp","../VueApp")
    .WithHttpEndpoint(env: "PORT")
    .WithExternalHttpEndpoints()
    .WithEnvironment("VITE_API_URL", webApp.GetEndpoint("http"))
    .WaitFor(webApp);

builder.Build().Run();