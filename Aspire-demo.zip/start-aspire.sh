#!/bin/bash

echo "================================================"
echo ".NET Aspire + Vue 3 应用启动脚本"
echo "================================================"

echo ""
echo "[1/3] 检查 Node.js 环境..."
if ! command -v node &> /dev/null; then
    echo "错误: 未检测到 Node.js，请先安装 Node.js 16+"
    exit 1
fi

echo ""
echo "[2/3] 检查 .NET 8.0 SDK..."
if ! command -v dotnet &> /dev/null; then
    echo "错误: 未检测到 .NET 8.0 SDK"
    exit 1
fi

echo ""
echo "[3/3] 启动 .NET Aspire 应用..."
echo "Vue 前端将在 http://localhost:3000 启动"
echo "WebApp 后端将在 http://localhost:5000 启动" 
echo "API 服务将在 http://localhost:5001 启动"
echo ""

dotnet run --project AppHost1