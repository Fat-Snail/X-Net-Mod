# .NET Aspire + Vue 3 集成说明

本项目已成功集成 Vue 3 前端应用与 .NET Aspire 后端服务。

## 项目结构

```
AppHost1/
├── AppHost1/           # Aspire 应用宿主
├── ApiService/         # API 后端服务
├── WebApp/            # Web 应用（后端）
├── VueApp/            # Vue 3 前端应用
│   ├── src/
│   │   ├── App.vue    # 主应用组件
│   │   ├── main.js    # 应用入口
│   │   └── style.css  # 全局样式
│   ├── package.json   # Node.js 配置
│   ├── vite.config.js # Vite 构建配置
│   └── VueApp.csproj  # .NET 项目文件
└── AppHost1.sln       # 解决方案文件
```

## 启动方式

### 方式一：使用 Aspire Dashboard（推荐）

```bash
# 在项目根目录执行
dotnet run --project AppHost1
```

这将启动：
- **Vue 前端**: http://localhost:3000
- **WebApp 后端**: http://localhost:5000  
- **API 服务**: http://localhost:5001
- **Aspire Dashboard**: http://localhost:18888

### 方式二：单独启动 Vue 前端

```bash
cd VueApp
npm install    # 首次运行需要安装依赖
npm run dev    # 启动开发服务器
```

## 功能特性

### Vue 前端功能
- ✅ 响应式 Vue 3 单页应用
- ✅ 与 .NET Aspire 后端服务集成
- ✅ API 代理配置（通过 WebApp 服务转发）
- ✅ 服务状态实时监控
- ✅ 天气预报数据展示
- ✅ 错误处理和加载状态

### 后端集成
- ✅ API 服务提供天气数据接口
- ✅ WebApp 服务作为 API 网关
- ✅ Vue 应用通过 WebApp 服务访问后端 API
- ✅ Aspire 服务发现和依赖管理

## API 接口

- `GET /api/hello` - 测试接口
- `GET /api/weather` - 获取天气预报数据

## 开发说明

### Vue 前端开发
1. 修改 VueApp/src/ 目录下的文件
2. 保存后自动热重载
3. 通过 http://localhost:3000 访问

### 后端开发
1. 修改 ApiService/ 或 WebApp/ 项目
2. Aspire 会自动重新构建和部署
3. 通过 Aspire Dashboard 监控服务状态

### 调试技巧
- 使用浏览器开发者工具查看网络请求
- 在 Aspire Dashboard 中查看服务日志
- Vue 开发工具支持 Vue 组件调试

## 部署说明

### 生产构建
```bash
# 构建 Vue 前端
cd VueApp
npm run build

# 发布 .NET 应用
dotnet publish -c Release
```

### 环境配置
- 开发环境：使用本地服务发现
- 生产环境：配置服务端点和反向代理

## 故障排除

### 常见问题

1. **Vue 应用无法启动**
   - 检查 Node.js 版本（需要 16+）
   - 运行 `npm install` 安装依赖

2. **API 请求失败**
   - 确认 WebApp 服务正在运行
   - 检查网络代理配置

3. **端口冲突**
   - 修改 VueApp/vite.config.js 中的端口号
   - 修改 .NET 项目的启动端口

### 日志查看
- Vue 前端：浏览器控制台
- 后端服务：Aspire Dashboard
- 系统日志：终端输出

---

**技术栈**: .NET 8.0 + Aspire + Vue 3 + Vite + Axios