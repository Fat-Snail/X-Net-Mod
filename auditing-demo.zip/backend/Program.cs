//using AuditingTest.Core.Audit;
using AuditingTest.Data;
using AuditingTest.Models;
using Microsoft.EntityFrameworkCore;
using OctopusEx.WebCore.Extensions;
using OctopusEx.WebCore.Interceptors.Auditing;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllers();

// Add CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

// Add Auditing Services with configuration
builder.Services.AddAuditing(config =>
{
    // 全局配置 - 启用所有审计
    config.Enabled = true;
    
    // 配置产品领域 - 使用Lambda表达式
    config.ConfigureDomain<Product>(cfg =>
    {
        cfg.Enabled = true;
        cfg.Ignore(p => p.CreatedAt);
        cfg.Ignore(p => p.InternalCode);
        cfg.Ignore(p => p.LastPrice);
        cfg.Ignore(p => p.SupplierInfo);
    });
    
    // 配置订单领域 - 使用Lambda表达式
    config.ConfigureDomain<Order>(cfg =>
    {
        cfg.Enabled = true;
        cfg.Ignore("InternalOrderCode", "DiscountAmount", "SalesPerson", "PaymentMethod");
    });
    
    // 配置日志领域 - 完全禁用审计
    config.ConfigureDomain<SystemLog>(cfg =>
    {
        cfg.Enabled = false;
    });
    
    // 配置系统领域 - 使用Lambda表达式
    config.ConfigureDomain<User>(cfg =>
    {
        cfg.Enabled = true;
        cfg.Ignore("PasswordHash", "SecurityStamp", "Token");
    });
    
    // 禁用审计日志自身的审计
    config.DisableDomain("Audit");
});

// Add DbContext with SQLite and Audit Interceptor
builder.Services.AddDbContext<ApplicationDbContext>((serviceProvider, options) =>
    options.UseSqlite("Data Source=auditing.db")
           .UseAuditing(serviceProvider));

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
// 在开发和生产环境下都启用Swagger
app.UseSwagger();
app.UseSwaggerUI();

app.UseCors("AllowAll");
app.UseAuthorization();
app.MapControllers();

// Initialize database
try
{
    using var scope = app.Services.CreateScope();
    var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
    await context.Database.EnsureCreatedAsync();
    
    // Seed some test data
    if (!context.Products.Any())
    {
        context.Products.AddRange(
            new AuditingTest.Models.Product 
            { 
                Name = "笔记本电脑", 
                Description = "高性能笔记本电脑", 
                Price = 5999.99m, 
                StockQuantity = 50,
                CreatedAt = DateTime.UtcNow,
                CreatedBy = "System"
            },
            new AuditingTest.Models.Product 
            { 
                Name = "智能手机", 
                Description = "最新款智能手机", 
                Price = 3999.99m, 
                StockQuantity = 100,
                CreatedAt = DateTime.UtcNow,
                CreatedBy = "System"
            }
        );
        await context.SaveChangesAsync();
    }
}
catch (Exception ex)
{
    Console.WriteLine($"Database initialization error: {ex.Message}");
}

app.Run("http://localhost:5100");