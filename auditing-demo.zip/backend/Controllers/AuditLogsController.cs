using AuditingTest.Data;
using AuditingTest.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;
using OctopusEx.WebCore.Interceptors;

namespace AuditingTest.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuditLogsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public AuditLogsController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<object>>> GetAuditLogs(
            [FromQuery] string? tableName = null,
            [FromQuery] string? entityId = null,
            [FromQuery] int page = 1,
            [FromQuery] int pageSize = 20)
        {
            var query = _context.AuditLogs.AsQueryable();

            if (!string.IsNullOrEmpty(tableName))
            {
                query = query.Where(x => x.TableName == tableName);
            }

            if (!string.IsNullOrEmpty(entityId))
            {
                query = query.Where(x => x.EntityId == entityId);
            }

            var totalCount = await query.CountAsync();
            
            // 先获取数据，然后处理JSON反序列化
            var auditLogs = await query
                .OrderByDescending(x => x.Timestamp)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            var result = auditLogs.Select(x => new
            {
                x.Id,
                x.TableName,
                x.EntityId,
                x.Action,
                x.Timestamp,
                x.UserName,
                Changes = JsonSerializer.Deserialize<List<PropertyChange>>(x.Changes ?? "[]") ?? new List<PropertyChange>(),
                x.OldValues,
                x.NewValues
            }).ToList();

            return Ok(new
            {
                TotalCount = totalCount,
                Page = page,
                PageSize = pageSize,
                TotalPages = (int)Math.Ceiling(totalCount / (double)pageSize),
                Data = result
            });
        }

        [HttpGet("{entityId}/changes")]
        public async Task<ActionResult<IEnumerable<object>>> GetEntityChanges(string entityId)
        {
            var changes = await _context.AuditLogs
                .Where(x => x.EntityId == entityId)
                .OrderBy(x => x.Timestamp)
                .ToListAsync();

            var result = changes.Select(x => new
            {
                x.Id,
                x.Action,
                x.Timestamp,
                x.UserName,
                Changes = JsonSerializer.Deserialize<List<PropertyChange>>(x.Changes ?? "[]") ?? new List<PropertyChange>(),
                x.OldValues,
                x.NewValues
            }).ToList();

            return Ok(result);
        }

        [HttpGet("tables")]
        public async Task<ActionResult<IEnumerable<string>>> GetAuditedTables()
        {
            var tables = await _context.AuditLogs
                .Select(x => x.TableName)
                .Distinct()
                .ToListAsync();

            return Ok(tables);
        }
    }
}