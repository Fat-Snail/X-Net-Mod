using AuditingTest.Data;
using AuditingTest.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AuditingTest.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class SystemLogsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public SystemLogsController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<SystemLog>>> GetSystemLogs()
        {
            return await _context.SystemLogs.OrderByDescending(l => l.Timestamp).ToListAsync();
        }

        [HttpPost]
        public async Task<ActionResult<SystemLog>> PostSystemLog(SystemLog systemLog)
        {
            systemLog.Timestamp = DateTime.UtcNow;
            _context.SystemLogs.Add(systemLog);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetSystemLogs), new { id = systemLog.Id }, systemLog);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteSystemLog(int id)
        {
            var systemLog = await _context.SystemLogs.FindAsync(id);
            if (systemLog == null)
            {
                return NotFound();
            }

            _context.SystemLogs.Remove(systemLog);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}