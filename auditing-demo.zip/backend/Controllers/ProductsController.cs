using AuditingTest.Models;
using AuditingTest.Services;
using Microsoft.AspNetCore.Mvc;
using OctopusEx.WebCore.DomainCore.APICommon;
using OctopusEx.WebCore.DomainCore.Implementations.Controllers;

namespace AuditingTest.Controllers
{
    /// <summary>
    /// 产品控制器（继承自通用CRUD控制器基类）
    /// </summary>
    public class ProductsController : CURDControllerBase<Product, int, ProductDto>
    {
        public ProductsController(ProductService productService)
            : base(productService)
        {
        }

        /// <summary>
        /// 从DTO中获取实体主键值
        /// </summary>
        protected override int GetEntityIdFromDto(ProductDto dto)
        {
            return dto.Id ?? throw new ArgumentException("Product Id is required");
        }

        /// <summary>
        /// 验证创建请求
        /// </summary>
        protected override async Task<ValidationResult> ValidateCreateRequestAsync(ProductDto request, CancellationToken cancellationToken)
        {
            // 基本验证
            if (string.IsNullOrWhiteSpace(request.Name))
            {
                return ValidationResult.Fail("产品名称不能为空");
            }

            if (request.Name.Length > 100)
            {
                return ValidationResult.Fail("产品名称长度不能超过100个字符");
            }

            if (request.Price <= 0)
            {
                return ValidationResult.Fail("产品价格必须大于0");
            }

            if (request.StockQuantity < 0)
            {
                return ValidationResult.Fail("库存数量不能为负数");
            }

            if (request.Description?.Length > 500)
            {
                return ValidationResult.Fail("产品描述长度不能超过500个字符");
            }

            // 可以添加更多业务验证逻辑
            // 例如：检查产品名称是否重复等

            return await base.ValidateCreateRequestAsync(request, cancellationToken);
        }

        /// <summary>
        /// 验证更新请求
        /// </summary>
        protected override async Task<ValidationResult> ValidateUpdateRequestAsync(int id, ProductDto request, CancellationToken cancellationToken)
        {
            // 基本验证
            if (string.IsNullOrWhiteSpace(request.Name))
            {
                return ValidationResult.Fail("产品名称不能为空");
            }

            if (request.Name.Length > 100)
            {
                return ValidationResult.Fail("产品名称长度不能超过100个字符");
            }

            if (request.Price <= 0)
            {
                return ValidationResult.Fail("产品价格必须大于0");
            }

            if (request.StockQuantity < 0)
            {
                return ValidationResult.Fail("库存数量不能为负数");
            }

            if (request.Description?.Length > 500)
            {
                return ValidationResult.Fail("产品描述长度不能超过500个字符");
            }

            // 确保ID匹配
            if (request.Id.HasValue && request.Id.Value != id)
            {
                return ValidationResult.Fail("请求中的ID与路由中的ID不匹配");
            }

            return await base.ValidateUpdateRequestAsync(id, request, cancellationToken);
        }

        /// <summary>
        /// 创建前处理
        /// </summary>
        protected override async Task BeforeCreateAsync(ProductDto request, CancellationToken cancellationToken)
        {
            // 可以在这里添加创建前的业务逻辑
            // 例如：生成产品编码、设置默认值等

            await base.BeforeCreateAsync(request, cancellationToken);
        }

        /// <summary>
        /// 更新前处理
        /// </summary>
        protected override async Task BeforeUpdateAsync(int id, ProductDto request, CancellationToken cancellationToken)
        {
            // 可以在这里添加更新前的业务逻辑
            // 例如：记录价格变更历史等

            await base.BeforeUpdateAsync(id, request, cancellationToken);
        }

        /// <summary>
        /// 检查是否可以删除
        /// </summary>
        protected override async Task<DeleteCheckResult> CanDeleteAsync(int id, CancellationToken cancellationToken)
        {
            // 检查产品是否有关联的订单或库存
            // 如果产品已经被使用，则不能删除

            // 这里可以调用服务层检查关联关系
            // 暂时返回允许删除
            return await base.CanDeleteAsync(id, cancellationToken);
        }

        /// <summary>
        /// 自定义端点示例：根据价格范围查询产品
        /// </summary>
        [HttpGet("by-price-range")]
        public async Task<ActionResult<BaseResponse<List<ProductDto>>>> GetProductsByPriceRange(
            [FromQuery] decimal minPrice,
            [FromQuery] decimal maxPrice,
            CancellationToken cancellationToken = default)
        {
            try
            {
                if (minPrice < 0 || maxPrice < 0 || minPrice > maxPrice)
                {
                    return BadRequest(BaseResponse<List<ProductDto>>.Error("价格范围参数无效"));
                }

                // 这里可以调用服务层的自定义方法
                // 暂时使用获取所有然后过滤的方式
                var allProducts = await Service.GetAllAsync(cancellationToken);
                var filteredProducts = allProducts
                    .Where(p => p.Price >= minPrice && p.Price <= maxPrice)
                    .ToList();

                return Ok(BaseResponse<List<ProductDto>>.Success(filteredProducts, "获取成功"));
            }
            catch (Exception ex)
            {
                return HandleException(ex);
            }
        }

        /// <summary>
        /// 自定义端点示例：更新产品库存
        /// </summary>
        [HttpPatch("{id}/stock")]
        public async Task<ActionResult<BaseResponse<ProductDto>>> UpdateStock(
            int id,
            [FromBody] StockUpdateRequest request,
            CancellationToken cancellationToken = default)
        {
            try
            {
                if (request == null)
                {
                    return BadRequest(BaseResponse<ProductDto>.Error("请求数据不能为空"));
                }

                // 获取现有产品
                var productDto = await Service.GetAsync(id, cancellationToken);
                if (productDto == null)
                {
                    return NotFound(BaseResponse<ProductDto>.Error("产品不存在"));
                }

                // 更新库存
                productDto.StockQuantity = request.NewStockQuantity;

                // 调用服务层更新
                var updatedProduct = await Service.UpdateAsync(productDto, cancellationToken);

                return Ok(BaseResponse<ProductDto>.Success(updatedProduct, "库存更新成功"));
            }
            catch (Exception ex)
            {
                return HandleException(ex);
            }
        }

        /// <summary>
        /// 库存更新请求
        /// </summary>
        public class StockUpdateRequest
        {
            public int NewStockQuantity { get; set; }
            public string? Reason { get; set; }
        }
    }
}