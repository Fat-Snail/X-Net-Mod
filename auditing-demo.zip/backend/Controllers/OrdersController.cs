using AuditingTest.Models;
using AuditingTest.Services;
using Microsoft.AspNetCore.Mvc;
using OctopusEx.WebCore.DomainCore.APICommon;
using OctopusEx.WebCore.DomainCore.Implementations.Controllers;

namespace AuditingTest.Controllers
{
    /// <summary>
    /// 订单控制器（继承自通用CRUD控制器基类）
    /// </summary>
    public class OrdersController : CURDControllerBase<Order, int, OrderDto>
    {
        public OrdersController(OrderService orderService)
            : base(orderService)
        {
        }

        /// <summary>
        /// 从DTO中获取实体主键值
        /// </summary>
        protected override int GetEntityIdFromDto(OrderDto dto)
        {
            return dto.Id ?? throw new ArgumentException("Order Id is required");
        }

        /// <summary>
        /// 验证创建请求
        /// </summary>
        protected override async Task<ValidationResult> ValidateCreateRequestAsync(OrderDto request, CancellationToken cancellationToken)
        {
            // 基本验证
            if (string.IsNullOrWhiteSpace(request.OrderNumber))
            {
                return ValidationResult.Fail("订单号不能为空");
            }

            if (string.IsNullOrWhiteSpace(request.CustomerName))
            {
                return ValidationResult.Fail("客户姓名不能为空");
            }

            if (request.TotalAmount <= 0)
            {
                return ValidationResult.Fail("订单金额必须大于0");
            }

            // 可以添加更多业务验证逻辑
            // 例如：检查订单号是否重复等

            return await base.ValidateCreateRequestAsync(request, cancellationToken);
        }

        /// <summary>
        /// 验证更新请求
        /// </summary>
        protected override async Task<ValidationResult> ValidateUpdateRequestAsync(int id, OrderDto request, CancellationToken cancellationToken)
        {
            // 基本验证
            if (string.IsNullOrWhiteSpace(request.OrderNumber))
            {
                return ValidationResult.Fail("订单号不能为空");
            }

            if (string.IsNullOrWhiteSpace(request.CustomerName))
            {
                return ValidationResult.Fail("客户姓名不能为空");
            }

            if (request.TotalAmount <= 0)
            {
                return ValidationResult.Fail("订单金额必须大于0");
            }

            // 确保ID匹配
            if (request.Id.HasValue && request.Id.Value != id)
            {
                return ValidationResult.Fail("请求中的ID与路由中的ID不匹配");
            }

            return await base.ValidateUpdateRequestAsync(id, request, cancellationToken);
        }

        /// <summary>
        /// 创建前处理
        /// </summary>
        protected override async Task BeforeCreateAsync(OrderDto request, CancellationToken cancellationToken)
        {
            // 可以在这里添加创建前的业务逻辑
            // 例如：生成订单号、设置默认值等

            await base.BeforeCreateAsync(request, cancellationToken);
        }

        /// <summary>
        /// 更新前处理
        /// </summary>
        protected override async Task BeforeUpdateAsync(int id, OrderDto request, CancellationToken cancellationToken)
        {
            // 可以在这里添加更新前的业务逻辑

            await base.BeforeUpdateAsync(id, request, cancellationToken);
        }

        /// <summary>
        /// 检查是否可以删除
        /// </summary>
        protected override async Task<DeleteCheckResult> CanDeleteAsync(int id, CancellationToken cancellationToken)
        {
            // 可以在这里添加删除前的业务检查
            // 例如：检查订单状态是否允许删除

            return await base.CanDeleteAsync(id, cancellationToken);
        }

        /// <summary>
        /// 自定义端点示例：根据订单状态查询订单
        /// </summary>
        [HttpGet("by-status/{status}")]
        public async Task<ActionResult<BaseResponse<List<OrderDto>>>> GetOrdersByStatus(OrderStatus status, CancellationToken cancellationToken = default)
        {
            try
            {
                // 这里可以调用服务层的自定义方法
                // 暂时使用获取所有然后过滤的方式
                var allOrders = await Service.GetAllAsync(cancellationToken);
                var filteredOrders = allOrders.Where(o => o.Status == status).ToList();

                return Ok(BaseResponse<List<OrderDto>>.Success(filteredOrders, "获取成功"));
            }
            catch (Exception ex)
            {
                return HandleException(ex);
            }
        }
    }
}