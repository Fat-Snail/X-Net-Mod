using AuditingTest.Models;
using Microsoft.EntityFrameworkCore;
using OctopusEx.WebCore.Interceptors.Auditing;

namespace AuditingTest.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<Product> Products => Set<Product>();
        public DbSet<User> Users => Set<User>();
        public DbSet<Order> Orders => Set<Order>();
        public DbSet<SystemLog> SystemLogs => Set<SystemLog>();
        public DbSet<AuditLog> AuditLogs => Set<AuditLog>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // 配置产品表
            modelBuilder.Entity<Product>(entity =>
            {
                entity.Property(p => p.Price).HasColumnType("decimal(18,2)");
                entity.Property(p => p.LastPrice).HasColumnType("decimal(18,2)");
            });

            // 配置订单表
            modelBuilder.Entity<Order>(entity =>
            {
                entity.Property(o => o.TotalAmount).HasColumnType("decimal(18,2)");
                entity.Property(o => o.DiscountAmount).HasColumnType("decimal(18,2)");
            });

            // 配置系统日志表
            modelBuilder.Entity<SystemLog>(entity =>
            {
                entity.Property(s => s.Timestamp).HasDefaultValueSql("datetime('now')");
            });

            // 配置审计日志表
            modelBuilder.Entity<AuditLog>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Changes).HasColumnType("TEXT");
                entity.Property(e => e.OldValues).HasColumnType("TEXT");
                entity.Property(e => e.NewValues).HasColumnType("TEXT");
            });
        }
    }
}