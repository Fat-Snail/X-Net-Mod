using AuditingTest.Models;
using Microsoft.EntityFrameworkCore;
using OctopusEx.WebCore.DomainCore.EFAdapters;
using OctopusEx.WebCore.Interceptors.Auditing;
using OctopusEx.WebCore.Repositories.Interfaces;

namespace AuditingTest.Data
{
    public class ApplicationDbContext : DbContext, IDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<Product> Products { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<SystemLog> SystemLogs { get; set; }
        public DbSet<AuditLog> AuditLogs { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // 配置产品表
            modelBuilder.Entity<Product>(entity =>
            {
                entity.Property(p => p.Price).HasColumnType("decimal(18,2)");
                entity.Property(p => p.LastPrice).HasColumnType("decimal(18,2)");
            });

            // 配置订单表
            modelBuilder.Entity<Order>(entity =>
            {
                entity.Property(o => o.TotalAmount).HasColumnType("decimal(18,2)");
                entity.Property(o => o.DiscountAmount).HasColumnType("decimal(18,2)");
            });

            // 配置系统日志表
            modelBuilder.Entity<SystemLog>(entity =>
            {
                entity.Property(s => s.Timestamp).HasDefaultValueSql("datetime('now')");
            });

            // 配置审计日志表
            modelBuilder.Entity<AuditLog>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Changes).HasColumnType("TEXT");
                entity.Property(e => e.OldValues).HasColumnType("TEXT");
                entity.Property(e => e.NewValues).HasColumnType("TEXT");
            });
        }

        public IDbSet<TEntity> Set<TEntity>() where TEntity : class
            => new EFDbSetAdapter<TEntity>(base.Set<TEntity>());

        public async Task<ITransaction> BeginTransactionAsync(CancellationToken cancellationToken = default)
        {
            var transaction = await Database.BeginTransactionAsync(cancellationToken);
            return new EFTransactionAdapter(transaction);
        }
    }
}