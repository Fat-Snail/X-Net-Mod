using AuditingTest.Models;
using OctopusEx.WebCore.DomainCore.Implementations.Services;
using OctopusEx.WebCore.Repositories.Interfaces;

namespace AuditingTest.Services
{
    /// <summary>
    /// Order CRUD服务
    /// </summary>
    public class OrderService : CrudServiceBase<Order, int, OrderDto, OrderDto, OrderDto>
    {
        public OrderService(IUnitOfWork unitOfWork)
            : base(unitOfWork)
        {
        }

        /// <summary>
        /// 从更新请求中获取主键
        /// </summary>
        protected override int GetUpdateRequestId(OrderDto request)
        {
            return request.Id ?? throw new ArgumentException("Order Id is required for update");
        }

        /// <summary>
        /// 获取实体的主键值
        /// </summary>
        protected override int GetEntityId(Order entity)
        {
            return entity.Id;
        }

        /// <summary>
        /// 将实体映射到DTO
        /// </summary>
        protected override OrderDto MapToDto(Order entity)
        {
            return new OrderDto
            {
                Id = entity.Id,
                OrderNumber = entity.OrderNumber,
                CustomerName = entity.CustomerName,
                TotalAmount = entity.TotalAmount,
                OrderDate = entity.OrderDate,
                Status = entity.Status,
                InternalOrderCode = entity.InternalOrderCode,
                DiscountAmount = entity.DiscountAmount,
                SalesPerson = entity.SalesPerson,
                PaymentMethod = entity.PaymentMethod,
                IsActive = entity.IsActive
            };
        }

        /// <summary>
        /// 将创建DTO映射到实体
        /// </summary>
        protected override Order MapToEntity(OrderDto createDto)
        {
            return createDto.ToOrder();
        }

        /// <summary>
        /// 使用更新DTO更新实体
        /// </summary>
        protected override void UpdateEntityFromDto(Order entity, OrderDto updateDto)
        {
            entity.OrderNumber = updateDto.OrderNumber;
            entity.CustomerName = updateDto.CustomerName;
            entity.TotalAmount = updateDto.TotalAmount;
            entity.OrderDate = updateDto.OrderDate;
            entity.Status = updateDto.Status;
            entity.InternalOrderCode = updateDto.InternalOrderCode;
            entity.DiscountAmount = updateDto.DiscountAmount;
            entity.SalesPerson = updateDto.SalesPerson;
            entity.PaymentMethod = updateDto.PaymentMethod;
            entity.IsActive = updateDto.IsActive;
        }

        /// <summary>
        /// 创建前处理
        /// </summary>
        protected override async Task BeforeCreateAsync(Order entity, OrderDto request, CancellationToken cancellationToken)
        {
            entity.CreatedAt = DateTime.UtcNow;
            entity.CreatedBy = "System User";
            entity.OrderDate = DateTime.UtcNow;
            await base.BeforeCreateAsync(entity, request, cancellationToken);
        }

        /// <summary>
        /// 更新前处理
        /// </summary>
        protected override async Task BeforeUpdateAsync(Order entity, OrderDto request, CancellationToken cancellationToken)
        {
            entity.UpdatedAt = DateTime.UtcNow;
            entity.UpdatedBy = "System User";
            await base.BeforeUpdateAsync(entity, request, cancellationToken);
        }
    }
}