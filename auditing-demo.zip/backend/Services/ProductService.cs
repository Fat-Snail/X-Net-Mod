using AuditingTest.Models;
using OctopusEx.WebCore.DomainCore.Implementations.Services;
using OctopusEx.WebCore.Repositories.Interfaces;

namespace AuditingTest.Services
{
    /// <summary>
    /// Product CRUD服务
    /// </summary>
    public class ProductService : CrudServiceBase<Product, int, ProductDto, ProductDto, ProductDto>
    {
        public ProductService(IUnitOfWork unitOfWork)
            : base(unitOfWork)
        {
        }

        /// <summary>
        /// 从更新请求中获取主键
        /// </summary>
        protected override int GetUpdateRequestId(ProductDto request)
        {
            return request.Id ?? throw new ArgumentException("Product Id is required for update");
        }

        /// <summary>
        /// 获取实体的主键值
        /// </summary>
        protected override int GetEntityId(Product entity)
        {
            return entity.Id;
        }

        /// <summary>
        /// 将实体映射到DTO
        /// </summary>
        protected override ProductDto MapToDto(Product entity)
        {
            return new ProductDto
            {
                Id = entity.Id,
                Name = entity.Name,
                Description = entity.Description,
                Price = entity.Price,
                StockQuantity = entity.StockQuantity,
                IsActive = entity.IsActive,
                InternalCode = entity.InternalCode,
                LastPrice = entity.LastPrice,
                SupplierInfo = entity.SupplierInfo
            };
        }

        /// <summary>
        /// 将创建DTO映射到实体
        /// </summary>
        protected override Product MapToEntity(ProductDto createDto)
        {
            return createDto.ToProduct();
        }

        /// <summary>
        /// 使用更新DTO更新实体
        /// </summary>
        protected override void UpdateEntityFromDto(Product entity, ProductDto updateDto)
        {
            entity.Name = updateDto.Name;
            entity.Description = updateDto.Description;
            entity.Price = updateDto.Price;
            entity.StockQuantity = updateDto.StockQuantity;
            entity.IsActive = updateDto.IsActive;
            entity.InternalCode = updateDto.InternalCode;
            entity.LastPrice = updateDto.LastPrice;
            entity.SupplierInfo = updateDto.SupplierInfo;
        }

        /// <summary>
        /// 创建前处理
        /// </summary>
        protected override async Task BeforeCreateAsync(Product entity, ProductDto request, CancellationToken cancellationToken)
        {
            entity.CreatedAt = DateTime.UtcNow;
            entity.CreatedBy = "System User";
            await base.BeforeCreateAsync(entity, request, cancellationToken);
        }

        /// <summary>
        /// 更新前处理
        /// </summary>
        protected override async Task BeforeUpdateAsync(Product entity, ProductDto request, CancellationToken cancellationToken)
        {
            entity.UpdatedAt = DateTime.UtcNow;
            entity.UpdatedBy = "System User";
            await base.BeforeUpdateAsync(entity, request, cancellationToken);
        }
    }
}