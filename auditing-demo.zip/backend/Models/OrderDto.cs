namespace AuditingTest.Models
{
    public class OrderDto
    {
        public int? Id { get; set; }
        public string OrderNumber { get; set; } = string.Empty;
        public string CustomerName { get; set; } = string.Empty;
        public decimal TotalAmount { get; set; }
        public DateTime OrderDate { get; set; }
        public OrderStatus Status { get; set; }
        public string InternalOrderCode { get; set; } = string.Empty;
        public decimal? DiscountAmount { get; set; }
        public string SalesPerson { get; set; } = string.Empty;
        public string PaymentMethod { get; set; } = string.Empty;
        public bool IsActive { get; set; } = true;

        // 转换为Order实体
        public Order ToOrder()
        {
            return new Order
            {
                Id = this.Id ?? 0,
                OrderNumber = this.OrderNumber,
                CustomerName = this.CustomerName,
                TotalAmount = this.TotalAmount,
                OrderDate = this.OrderDate,
                Status = this.Status,
                InternalOrderCode = this.InternalOrderCode,
                DiscountAmount = this.DiscountAmount,
                SalesPerson = this.SalesPerson,
                PaymentMethod = this.PaymentMethod,
                IsActive = this.IsActive
            };
        }
    }
}