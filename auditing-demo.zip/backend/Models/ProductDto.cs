namespace AuditingTest.Models
{
    public class ProductDto
    {
        public int? Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string? Description { get; set; }
        public decimal Price { get; set; }
        public int StockQuantity { get; set; }
        public bool IsActive { get; set; } = true;
        public string InternalCode { get; set; } = string.Empty;
        public decimal? LastPrice { get; set; }
        public string SupplierInfo { get; set; } = string.Empty;

        // 转换为Product实体
        public Product ToProduct()
        {
            return new Product
            {
                Id = this.Id ?? 0,
                Name = this.Name,
                Description = this.Description,
                Price = this.Price,
                StockQuantity = this.StockQuantity,
                IsActive = this.IsActive,
                InternalCode = this.InternalCode,
                LastPrice = this.LastPrice,
                SupplierInfo = this.SupplierInfo
            };
        }
    }
}