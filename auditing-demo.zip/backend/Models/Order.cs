namespace AuditingTest.Models
{
    public class Order : IAuditableEntity
    {
        public int Id { get; set; }
        public string OrderNumber { get; set; } = string.Empty;
        public string CustomerName { get; set; } = string.Empty;
        public decimal TotalAmount { get; set; }
        public DateTime OrderDate { get; set; }
        public OrderStatus Status { get; set; }
        
        // 被忽略的字段 - 这些字段的变更不会被审计
        public string InternalOrderCode { get; set; } = string.Empty; // 内部订单编码
        public decimal? DiscountAmount { get; set; } // 折扣金额
        public string SalesPerson { get; set; } = string.Empty; // 销售人员
        public string PaymentMethod { get; set; } = string.Empty; // 支付方式
        
        // 审计字段
        public DateTime CreatedAt { get; set; }
        public string CreatedBy { get; set; } = string.Empty;
        public DateTime? UpdatedAt { get; set; }
        public string? UpdatedBy { get; set; }
        public bool IsActive { get; set; } = true;
    }

    public enum OrderStatus
    {
        Pending = 0,    // 待处理
        Confirmed = 1,  // 已确认
        Shipped = 2,    // 已发货
        Delivered = 3,  // 已送达
        Cancelled = 4   // 已取消
    }
}