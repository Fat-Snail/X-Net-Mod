namespace AuditingTest.Models
{
    /// <summary>
    /// 系统日志实体 - 不实现 IAuditableEntity，整个领域被忽略审计
    /// </summary>
    public class SystemLog
    {
        public int Id { get; set; }
        public string Level { get; set; } = string.Empty; // INFO, WARN, ERROR
        public string Message { get; set; } = string.Empty;
        public string Source { get; set; } = string.Empty;
        public DateTime Timestamp { get; set; }
        public string? Exception { get; set; }
        public string? StackTrace { get; set; }
        
        // 注意：这个实体不实现 IAuditableEntity
        // 因此不会有 CreatedAt, CreatedBy, UpdatedAt, UpdatedBy 等审计字段
        
        // 业务相关字段
        public string? UserId { get; set; }
        public string? UserName { get; set; }
        public string? IpAddress { get; set; }
        public string? RequestPath { get; set; }
        public string? RequestMethod { get; set; }
    }

    public enum LogLevel
    {
        Info = 0,
        Warning = 1,
        Error = 2,
        Critical = 3
    }
}