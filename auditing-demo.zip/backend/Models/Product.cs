using System.ComponentModel.DataAnnotations;

namespace AuditingTest.Models
{
    public class Product : IAuditableEntity
    {
        public int Id { get; set; }
        
        [Required]
        [StringLength(100)]
        public string Name { get; set; } = string.Empty;
        
        [StringLength(500)]
        public string? Description { get; set; }
        
        [Range(0, double.MaxValue)]
        public decimal Price { get; set; }
        
        [Range(0, int.MaxValue)]
        public int StockQuantity { get; set; }
        
        public bool IsActive { get; set; } = true;
        
        // 被忽略的字段 - 这些字段的变更不会被审计
        public string InternalCode { get; set; } = string.Empty;
        public decimal? LastPrice { get; set; }
        public string SupplierInfo { get; set; } = string.Empty;
        
        // 审计字段
        public DateTime CreatedAt { get; set; }
        public string CreatedBy { get; set; } = string.Empty;
        public DateTime? UpdatedAt { get; set; }
        public string? UpdatedBy { get; set; }
    }
}