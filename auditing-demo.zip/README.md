# 数据库操作审计系统

一个基于C# EFCore和Vue3的完整数据库操作审计系统，能够记录实体操作的具体变化值并实时显示。

## 功能特性

- ✅ **EFCore审计拦截器** - 自动记录所有实体操作
- ✅ **详细变更记录** - 记录每个字段的旧值和新值
- ✅ **Vue3前端界面** - 现代化用户界面
- ✅ **实时审计显示** - 左侧编辑，右侧查看审计记录
- ✅ **操作类型识别** - INSERT、UPDATE、DELETE操作区分
- ✅ **时间轴展示** - 按时间顺序显示所有变更

## 项目结构

```
auditing-test/
├── backend/                 # C#后端项目
│   ├── Controllers/         # API控制器
│   ├── Data/               # 数据访问层
│   ├── Models/             # 数据模型
│   ├── Program.cs          # 应用入口
│   └── AuditingTest.csproj # 项目配置
├── frontend/               # Vue3前端项目
│   ├── src/
│   │   ├── views/          # 页面组件
│   │   ├── services/       # API服务
│   │   ├── router/         # 路由配置
│   │   └── main.js         # 应用入口
│   └── package.json        # 依赖配置
└── README.md
```

## 快速开始

### 后端启动

1. 进入后端目录
```bash
cd backend
```

2. 安装依赖并启动
```bash
dotnet restore
dotnet run
```

后端服务将在 `http://localhost:5000` 启动

### 前端启动

1. 进入前端目录
```bash
cd frontend
```

2. 安装依赖
```bash
npm install
```

3. 启动开发服务器
```bash
npm run dev
```

前端应用将在 `http://localhost:3000` 启动

## 使用说明

1. **产品管理**：在左侧面板可以新增、编辑、删除产品
2. **查看审计**：点击产品操作列的"查看审计"按钮
3. **审计记录**：右侧面板实时显示该产品的所有操作记录
4. **变更详情**：每个变更记录显示具体字段的旧值和新值

## 技术栈

### 后端
- .NET 8.0
- Entity Framework Core 8.0
- ASP.NET Core Web API
- SQL Server LocalDB

### 前端
- Vue 3.3.4
- Element Plus UI组件库
- Vite构建工具
- Axios HTTP客户端

## API接口

### 产品管理
- `GET /api/products` - 获取产品列表
- `POST /api/products` - 创建产品
- `PUT /api/products/{id}` - 更新产品
- `DELETE /api/products/{id}` - 删除产品

### 审计日志
- `GET /api/auditlogs` - 获取审计日志列表
- `GET /api/auditlogs/{entityId}/changes` - 获取实体变更记录
- `GET /api/auditlogs/tables` - 获取已审计的表列表

## 审计功能实现

系统通过EFCore的`SaveChangesAsync`方法重写实现审计功能：

1. **变更检测**：使用`ChangeTracker`检测所有实体变更
2. **数据收集**：记录变更前后的字段值
3. **JSON存储**：将变更详情以JSON格式存储
4. **异步保存**：确保审计记录与业务数据一起保存

## 开发说明

### 添加新的审计实体

1. 让实体类实现`IAuditableEntity`接口
2. 在`ApplicationDbContext`中添加DbSet
3. 审计系统会自动处理所有变更记录

### 自定义审计规则

在`ApplicationDbContext.OnBeforeSaveChanges`方法中可以自定义审计规则，如：
- 过滤特定字段
- 添加业务逻辑
- 自定义用户信息获取