import axios from 'axios'

// 创建axios实例
const api = axios.create({
  baseURL: 'http://localhost:5100/api',
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json'
  }
})

// 请求拦截器
api.interceptors.request.use(
  (config) => {
    // 可以在这里添加认证token等
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

// 响应拦截器
api.interceptors.response.use(
  (response) => {
    return response
  },
  (error) => {
    console.error('API请求错误:', error)
    return Promise.reject(error)
  }
)

// 产品相关API
export default {
  // 产品管理
  getProducts: () => api.get('/products'),
  getProduct: (id) => api.get(`/products/${id}`),
  createProduct: (product) => api.post('/products', product),
  updateProduct: (id, product) => api.put(`/products/${id}`, product),
  deleteProduct: (id) => api.delete(`/products/${id}`),
  
  // 订单管理
  getOrders: () => api.get('/orders'),
  getOrder: (id) => api.get(`/orders/${id}`),
  createOrder: (order) => api.post('/orders', order),
  updateOrder: (id, order) => api.put(`/orders/${id}`, order),
  deleteOrder: (id) => api.delete(`/orders/${id}`),
  
  // 审计日志
  getAuditLogs: (params) => api.get('/auditlogs', { params }),
  getEntityAuditLogs: (entityId) => api.get(`/auditlogs/${entityId}/changes`),
  getAuditedTables: () => api.get('/auditlogs/tables')
}