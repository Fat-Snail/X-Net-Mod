import { createRouter, createWebHistory } from 'vue-router'
import ProductManagement from '../views/ProductManagement.vue'
import AuditDemo from '../views/AuditDemo.vue'
import OrderAuditDemo from '../views/OrderAuditDemo.vue'

const routes = [
  {
    path: '/',
    redirect: '/products'
  },
  {
    path: '/products',
    name: 'ProductManagement',
    component: ProductManagement
  },
  {
    path: '/audit-demo',
    name: 'AuditDemo',
    component: AuditDemo
  },
  {
    path: '/order-audit-demo',
    name: 'OrderAuditDemo',
    component: OrderAuditDemo
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router