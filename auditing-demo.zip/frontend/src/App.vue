<template>
  <div id="app">
    <el-container class="app-container">
      <el-header class="app-header">
        <h1>数据库操作审计系统</h1>
        <div class="nav-menu">
          <router-link to="/products" class="nav-link">产品管理</router-link>
          <router-link to="/audit-demo" class="nav-link">产品审计演示</router-link>
          <router-link to="/order-audit-demo" class="nav-link">订单审计演示</router-link>
        </div>
      </el-header>
      <el-main class="app-main">
        <router-view />
      </el-main>
    </el-container>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

#app {
  font-family: 'Helvetica Neue', Helvetica, 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', '微软雅黑', Arial, sans-serif;
  height: 100vh;
}

.app-container {
  height: 100vh;
}

.app-header {
  background-color: #409eff;
  color: white;
  display: flex;
  align-items: center;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.app-header h1 {
  margin: 0;
  font-size: 24px;
  font-weight: 500;
}

.app-main {
  padding: 0;
  height: calc(100vh - 60px);
}
</style>