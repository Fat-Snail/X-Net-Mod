<template>
  <div class="order-audit-demo">
    <h1>订单领域审计忽略演示</h1>
    
    <!-- 配置说明 -->
    <el-card class="config-card">
      <template #header>
        <span>Order 领域审计配置</span>
      </template>
      <div class="config-info">
        <h3>✅ 被审计的字段：</h3>
        <div class="tracked-properties">
          <el-tag v-for="prop in trackedProperties" :key="prop" type="success" class="property-tag">
            {{ prop }}
          </el-tag>
        </div>
        
        <h3>❌ 被忽略的字段（不审计）：</h3>
        <div class="ignored-properties">
          <el-tag v-for="prop in ignoredProperties" :key="prop" type="danger" class="property-tag">
            {{ prop }}
          </el-tag>
        </div>
        
        <p class="config-description">
          只有被审计的字段变更会被记录到审计日志中，被忽略的字段变更不会被审计
        </p>
      </div>
    </el-card>

    <!-- 演示操作区域 -->
    <el-row :gutter="20" class="demo-section">
      <el-col :span="12">
        <el-card class="operation-card">
          <template #header>
            <span>订单操作演示</span>
          </template>
          
          <el-form :model="orderForm" label-width="120px">
            <el-form-item label="订单号">
              <el-input v-model="orderForm.orderNumber" placeholder="输入订单号" />
              <span class="tracked-note">✅ 被审计</span>
            </el-form-item>
            
            <el-form-item label="客户名称">
              <el-input v-model="orderForm.customerName" placeholder="输入客户名称" />
              <span class="tracked-note">✅ 被审计</span>
            </el-form-item>
            
            <el-form-item label="订单金额">
              <el-input-number v-model="orderForm.totalAmount" :min="0" :precision="2" />
              <span class="tracked-note">✅ 被审计</span>
            </el-form-item>
            
            <el-form-item label="订单状态">
              <el-select v-model="orderForm.status" placeholder="选择订单状态">
                <el-option v-for="status in orderStatusOptions" :key="status.value" 
                           :label="status.label" :value="status.value" />
              </el-select>
              <span class="tracked-note">✅ 被审计</span>
            </el-form-item>
            
            <el-divider>被忽略的字段（不审计）</el-divider>
            
            <el-form-item label="内部订单编码">
              <el-input v-model="orderForm.internalOrderCode" placeholder="内部订单编码" />
              <span class="ignore-note">❌ 忽略审计</span>
            </el-form-item>
            
            <el-form-item label="折扣金额">
              <el-input-number v-model="orderForm.discountAmount" :min="0" :precision="2" />
              <span class="ignore-note">❌ 忽略审计</span>
            </el-form-item>
            
            <el-form-item label="销售人员">
              <el-input v-model="orderForm.salesPerson" placeholder="销售人员" />
              <span class="ignore-note">❌ 忽略审计</span>
            </el-form-item>
            
            <el-form-item label="支付方式">
              <el-input v-model="orderForm.paymentMethod" placeholder="支付方式" />
              <span class="ignore-note">❌ 忽略审计</span>
            </el-form-item>
          </el-form>
          
          <div class="operation-buttons">
            <el-button type="primary" @click="handleCreateOrder">创建订单</el-button>
            <el-button type="warning" @click="handleUpdateOrder" :disabled="!selectedOrder">
              更新订单
            </el-button>
            <el-button @click="showOrderList">选择订单</el-button>
            <el-button @click="resetForm">重置表单</el-button>
          </div>
        </el-card>
      </el-col>

      <el-col :span="12">
        <el-card class="audit-result-card">
          <template #header>
            <span>审计结果对比</span>
            <el-button size="small" @click="refreshAuditLogs" :icon="Refresh">刷新</el-button>
          </template>
          
          <div v-loading="auditLoading">
            <div v-if="selectedOrder" class="order-info">
              <h3>当前订单: {{ selectedOrder.orderNumber }}</h3>
              <p>客户: {{ selectedOrder.customerName }} | 金额: ¥{{ selectedOrder.totalAmount }}</p>
            </div>
            
            <div v-if="!selectedOrder" class="empty-state">
              <el-empty description="请先创建或选择一个订单" />
            </div>
            
            <div v-else-if="auditLogs.length === 0" class="empty-state">
              <el-empty description="暂无审计记录" />
            </div>
            
            <div v-else class="audit-comparison">
              <div v-for="log in auditLogs" :key="log.id" class="audit-item">
                <div class="audit-header">
                  <el-tag :type="getActionType(log.action)">{{ getActionText(log.action) }}</el-tag>
                  <span class="timestamp">{{ formatTime(log.timestamp) }}</span>
                  <span class="user">{{ log.userName }}</span>
                </div>
                
                <div class="changes-section">
                  <h4>✅ 被审计的字段变更：</h4>
                  <div v-if="log.changes && log.changes.length > 0" class="tracked-changes">
                    <div v-for="change in log.changes" :key="change.propertyName" class="change-item tracked">
                      <span class="property-name">{{ getPropertyName(change.propertyName) }}</span>
                      <span class="old-value" v-if="change.oldValue">{{ change.oldValue }}</span>
                      <span class="arrow" v-if="change.oldValue && change.newValue">→</span>
                      <span class="new-value" v-if="change.newValue">{{ change.newValue }}</span>
                    </div>
                  </div>
                  <div v-else class="no-tracked-changes">
                    <span>无被审计的字段变更</span>
                  </div>
                </div>
                
                <div class="ignored-section">
                  <h4>❌ 被忽略的字段（不记录审计）：</h4>
                  <div class="ignored-list">
                    <div v-for="prop in ignoredProperties" :key="prop" class="ignored-item">
                      <span class="property-name ignored">{{ getPropertyName(prop) }}</span>
                      <span class="ignored-badge">忽略审计</span>
                    </div>
                  </div>
                  <p class="ignored-description">
                    这些字段的变更不会被记录到审计日志中，即使它们被修改了
                  </p>
                </div>
              </div>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 订单选择对话框 -->
    <el-dialog v-model="orderDialogVisible" title="选择订单" width="800px">
      <el-table :data="orders" @row-click="selectOrder">
        <el-table-column prop="id" label="ID" width="60" />
        <el-table-column prop="orderNumber" label="订单号" width="120" />
        <el-table-column prop="customerName" label="客户" width="100" />
        <el-table-column prop="totalAmount" label="金额" width="100">
          <template #default="{ row }">¥{{ row.totalAmount }}</template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="100">
          <template #default="{ row }">{{ getStatusText(row.status) }}</template>
        </el-table-column>
        <el-table-column prop="internalOrderCode" label="内部编码" width="120" />
        <el-table-column prop="salesPerson" label="销售" width="100" />
        <el-table-column label="操作" width="100">
          <template #default="{ row }">
            <el-button size="small" @click="selectOrder(row)">选择</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-dialog>
  </div>
</template>

<script>
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { Refresh } from '@element-plus/icons-vue'
import api from '../services/api'

export default {
  name: 'OrderAuditDemo',
  components: {
    Refresh
  },
  setup() {
    const trackedProperties = ref(['OrderNumber', 'CustomerName', 'TotalAmount', 'Status'])
    const ignoredProperties = ref(['InternalOrderCode', 'DiscountAmount', 'SalesPerson', 'PaymentMethod'])
    const orders = ref([])
    const selectedOrder = ref(null)
    const auditLogs = ref([])
    const auditLoading = ref(false)
    const orderDialogVisible = ref(false)
    
    const orderStatusOptions = [
      { value: 0, label: '待处理' },
      { value: 1, label: '已确认' },
      { value: 2, label: '已发货' },
      { value: 3, label: '已送达' },
      { value: 4, label: '已取消' }
    ]
    
    const orderForm = ref({
      id: null,
      orderNumber: '',
      customerName: '',
      totalAmount: 0,
      status: 0,
      internalOrderCode: '',
      discountAmount: null,
      salesPerson: '',
      paymentMethod: ''
    })

    // 加载订单列表
    const loadOrders = async () => {
      try {
        const response = await api.getOrders()
        orders.value = response.data
      } catch (error) {
        ElMessage.error('加载订单列表失败')
      }
    }

    // 加载审计记录
    const loadAuditLogs = async (orderId) => {
      if (!orderId) return
      
      auditLoading.value = true
      try {
        const response = await api.getEntityAuditLogs(orderId.toString())
        auditLogs.value = response.data
      } catch (error) {
        ElMessage.error('加载审计记录失败')
      } finally {
        auditLoading.value = false
      }
    }

    // 创建订单
    const handleCreateOrder = async () => {
      try {
        await api.createOrder(orderForm.value)
        ElMessage.success('订单创建成功')
        resetForm()
        loadOrders()
      } catch (error) {
        ElMessage.error('创建订单失败')
      }
    }

    // 更新订单
    const handleUpdateOrder = async () => {
      if (!selectedOrder.value) return
      
      try {
        await api.updateOrder(selectedOrder.value.id, orderForm.value)
        ElMessage.success('订单更新成功')
        loadAuditLogs(selectedOrder.value.id)
      } catch (error) {
        ElMessage.error('更新订单失败')
      }
    }

    // 选择订单
    const selectOrder = (order) => {
      selectedOrder.value = order
      orderForm.value = { ...order }
      orderDialogVisible.value = false
      loadAuditLogs(order.id)
    }

    // 显示订单列表
    const showOrderList = () => {
      orderDialogVisible.value = true
    }

    // 重置表单
    const resetForm = () => {
      orderForm.value = {
        id: null,
        orderNumber: '',
        customerName: '',
        totalAmount: 0,
        status: 0,
        internalOrderCode: '',
        discountAmount: null,
        salesPerson: '',
        paymentMethod: ''
      }
    }

    // 刷新审计记录
    const refreshAuditLogs = () => {
      if (selectedOrder.value) {
        loadAuditLogs(selectedOrder.value.id)
      }
    }

    // 工具函数
    const getActionType = (action) => {
      const types = {
        'INSERT': 'success',
        'UPDATE': 'warning',
        'DELETE': 'danger'
      }
      return types[action] || 'info'
    }

    const getActionText = (action) => {
      const texts = {
        'INSERT': '新增',
        'UPDATE': '修改',
        'DELETE': '删除'
      }
      return texts[action] || action
    }

    const formatTime = (timestamp) => {
      return new Date(timestamp).toLocaleString('zh-CN')
    }

    const getPropertyName = (property) => {
      const names = {
        'orderNumber': '订单号',
        'customerName': '客户名称',
        'totalAmount': '订单金额',
        'status': '订单状态',
        'internalOrderCode': '内部订单编码',
        'discountAmount': '折扣金额',
        'salesPerson': '销售人员',
        'paymentMethod': '支付方式'
      }
      return names[property] || property
    }

    const getStatusText = (status) => {
      const statusMap = {
        0: '待处理',
        1: '已确认',
        2: '已发货',
        3: '已送达',
        4: '已取消'
      }
      return statusMap[status] || '未知'
    }

    onMounted(() => {
      loadOrders()
    })

    return {
      trackedProperties,
      ignoredProperties,
      orders,
      selectedOrder,
      auditLogs,
      auditLoading,
      orderDialogVisible,
      orderStatusOptions,
      orderForm,
      Refresh,
      handleCreateOrder,
      handleUpdateOrder,
      selectOrder,
      showOrderList,
      resetForm,
      refreshAuditLogs,
      getActionType,
      getActionText,
      formatTime,
      getPropertyName,
      getStatusText
    }
  }
}
</script>

<style scoped>
.order-audit-demo {
  padding: 20px;
}

.config-card {
  margin-bottom: 20px;
}

.config-info h3 {
  margin-top: 15px;
  color: #333;
}

.tracked-properties, .ignored-properties {
  display: flex;
  gap: 10px;
  margin: 10px 0;
  flex-wrap: wrap;
}

.property-tag {
  font-size: 14px;
}

.config-description {
  color: #666;
  font-style: italic;
  margin-top: 15px;
}

.demo-section {
  margin-top: 20px;
}

.operation-card, .audit-result-card {
  height: 700px;
}

.tracked-note {
  font-size: 12px;
  color: #67c23a;
  margin-left: 10px;
}

.ignore-note {
  font-size: 12px;
  color: #f56c6c;
  margin-left: 10px;
}

.operation-buttons {
  display: flex;
  gap: 10px;
  justify-content: center;
  margin-top: 20px;
}

.order-info {
  background: #f5f7fa;
  padding: 15px;
  border-radius: 4px;
  margin-bottom: 15px;
}

.empty-state {
  height: 500px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.audit-comparison {
  height: 600px;
  overflow-y: auto;
}

.audit-item {
  border: 1px solid #e6e6e6;
  border-radius: 6px;
  padding: 15px;
  margin-bottom: 15px;
  background: white;
}

.audit-header {
  display: flex;
  align-items: center;
  gap: 15px;
  margin-bottom: 15px;
}

.timestamp {
  color: #666;
  font-size: 14px;
}

.user {
  color: #999;
  font-size: 14px;
}

.changes-section, .ignored-section {
  margin-bottom: 15px;
}

.changes-section h4, .ignored-section h4 {
  margin: 0 0 10px 0;
  color: #333;
  font-size: 14px;
}

.tracked-changes, .ignored-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.change-item {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
  padding: 5px;
  border-radius: 3px;
}

.change-item.tracked {
  background: #f0f9eb;
}

.property-name {
  font-weight: 500;
  min-width: 120px;
}

.property-name.ignored {
  color: #999;
}

.old-value {
  color: #f56c6c;
  text-decoration: line-through;
}

.new-value {
  color: #67c23a;
}

.arrow {
  color: #909399;
}

.ignored-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 5px;
  background: #f5f5f5;
  border-radius: 3px;
}

.ignored-badge {
  background: #909399;
  color: white;
  padding: 2px 6px;
  border-radius: 3px;
  font-size: 12px;
}

.no-tracked-changes {
  color: #909399;
  font-style: italic;
  padding: 10px;
  text-align: center;
}

.ignored-description {
  color: #666;
  font-size: 12px;
  font-style: italic;
  margin-top: 5px;
}
</style>