<template>
  <div class="audit-demo">
    <h1>审计忽略演示</h1>
    
    <!-- 配置说明 -->
    <el-card class="config-card">
      <template #header>
        <span>当前审计配置</span>
      </template>
      <div class="config-info">
        <h3>Product 领域忽略的字段：</h3>
        <div class="ignored-properties">
          <el-tag v-for="prop in ignoredProperties" :key="prop" type="danger" class="property-tag">
            {{ prop }}
          </el-tag>
        </div>
        <p class="config-description">
          这些字段的变更将不会被记录到审计日志中
        </p>
      </div>
    </el-card>

    <!-- 演示操作区域 -->
    <el-row :gutter="20" class="demo-section">
      <el-col :span="12">
        <el-card class="operation-card">
          <template #header>
            <span>操作演示</span>
          </template>
          
          <el-form :model="productForm" label-width="100px">
            <el-form-item label="产品名称">
              <el-input v-model="productForm.name" placeholder="输入产品名称" />
            </el-form-item>
            
            <el-form-item label="描述">
              <el-input v-model="productForm.description" type="textarea" placeholder="输入产品描述" />
            </el-form-item>
            
            <el-form-item label="价格">
              <el-input-number v-model="productForm.price" :min="0" :precision="2" />
            </el-form-item>
            
            <el-form-item label="库存">
              <el-input-number v-model="productForm.stockQuantity" :min="0" />
            </el-form-item>
            
            <el-form-item label="内部编码">
              <el-input v-model="productForm.internalCode" placeholder="内部编码（被忽略）" />
              <span class="ignore-note">⚠️ 此字段变更不会被审计</span>
            </el-form-item>
            
            <el-form-item label="上次价格">
              <el-input-number v-model="productForm.lastPrice" :min="0" :precision="2" />
              <span class="ignore-note">⚠️ 此字段变更不会被审计</span>
            </el-form-item>
            
            <el-form-item label="供应商">
              <el-input v-model="productForm.supplierInfo" placeholder="供应商信息（被忽略）" />
              <span class="ignore-note">⚠️ 此字段变更不会被审计</span>
            </el-form-item>
            
            <el-form-item label="状态">
              <el-switch v-model="productForm.isActive" />
            </el-form-item>
          </el-form>
          
          <div class="operation-buttons">
            <el-button type="primary" @click="handleCreate">创建产品</el-button>
            <el-button type="warning" @click="handleUpdate" :disabled="!selectedProduct">
              更新产品
            </el-button>
            <el-button @click="showProductList">选择产品</el-button>
            <el-button @click="resetForm">重置表单</el-button>
          </div>
        </el-card>
      </el-col>

      <el-col :span="12">
        <el-card class="audit-result-card">
          <template #header>
            <span>审计结果对比</span>
            <el-button size="small" @click="refreshAuditLogs" :icon="Refresh">刷新</el-button>
          </template>
          
          <div v-loading="auditLoading">
            <div v-if="selectedProduct" class="product-info">
              <h3>当前产品: {{ selectedProduct.name }}</h3>
              <p>ID: {{ selectedProduct.id }}</p>
            </div>
            
            <div v-if="!selectedProduct" class="empty-state">
              <el-empty description="请先创建或选择一个产品" />
            </div>
            
            <div v-else-if="auditLogs.length === 0" class="empty-state">
              <el-empty description="暂无审计记录" />
            </div>
            
            <div v-else class="audit-comparison">
              <div v-for="log in auditLogs" :key="log.id" class="audit-item">
                <div class="audit-header">
                  <el-tag :type="getActionType(log.action)">{{ getActionText(log.action) }}</el-tag>
                  <span class="timestamp">{{ formatTime(log.timestamp) }}</span>
                  <span class="user">{{ log.userName }}</span>
                </div>
                
                <div class="changes-section">
                  <h4>被审计的字段变更：</h4>
                  <div v-if="log.changes && log.changes.length > 0" class="tracked-changes">
                    <div v-for="change in log.changes" :key="change.propertyName" class="change-item tracked">
                      <span class="property-name">{{ getPropertyName(change.propertyName) }}</span>
                      <span class="old-value" v-if="change.oldValue">{{ change.oldValue }}</span>
                      <span class="arrow" v-if="change.oldValue && change.newValue">→</span>
                      <span class="new-value" v-if="change.newValue">{{ change.newValue }}</span>
                    </div>
                  </div>
                  <div v-else class="no-tracked-changes">
                    <span>无被审计的字段变更</span>
                  </div>
                </div>
                
                <div class="ignored-section">
                  <h4>被忽略的字段（不记录审计）：</h4>
                  <div class="ignored-list">
                    <div v-for="prop in ignoredProperties" :key="prop" class="ignored-item">
                      <span class="property-name ignored">{{ getPropertyName(prop) }}</span>
                      <span class="ignored-badge">忽略审计</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 产品选择对话框 -->
    <el-dialog v-model="productDialogVisible" title="选择产品" width="600px">
      <el-table :data="products" @row-click="selectProduct">
        <el-table-column prop="id" label="ID" width="80" />
        <el-table-column prop="name" label="产品名称" />
        <el-table-column prop="price" label="价格" width="100">
          <template #default="{ row }">¥{{ row.price }}</template>
        </el-table-column>
        <el-table-column prop="stockQuantity" label="库存" width="80" />
        <el-table-column label="操作" width="100">
          <template #default="{ row }">
            <el-button size="small" @click="selectProduct(row)">选择</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-dialog>
  </div>
</template>

<script>
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { Refresh } from '@element-plus/icons-vue'
import api from '../services/api'

export default {
  name: 'AuditDemo',
  components: {
    Refresh
  },
  setup() {
    const ignoredProperties = ref(['InternalCode', 'LastPrice', 'SupplierInfo'])
    const products = ref([])
    const selectedProduct = ref(null)
    const auditLogs = ref([])
    const auditLoading = ref(false)
    const productDialogVisible = ref(false)
    
    const productForm = ref({
      id: null,
      name: '',
      description: '',
      price: 0,
      stockQuantity: 0,
      internalCode: '',
      lastPrice: 0,
      supplierInfo: '',
      isActive: true
    })

    // 加载产品列表
    const loadProducts = async () => {
      try {
        const response = await api.getProducts()
        products.value = response.data
      } catch (error) {
        ElMessage.error('加载产品列表失败')
      }
    }

    // 加载审计记录
    const loadAuditLogs = async (productId) => {
      if (!productId) return
      
      auditLoading.value = true
      try {
        const response = await api.getEntityAuditLogs(productId.toString())
        auditLogs.value = response.data
      } catch (error) {
        ElMessage.error('加载审计记录失败')
      } finally {
        auditLoading.value = false
      }
    }

    // 创建产品
    const handleCreate = async () => {
      try {
        await api.createProduct(productForm.value)
        ElMessage.success('产品创建成功')
        resetForm()
        loadProducts()
      } catch (error) {
        ElMessage.error('创建产品失败')
      }
    }

    // 更新产品
    const handleUpdate = async () => {
      if (!selectedProduct.value) return
      
      try {
        await api.updateProduct(selectedProduct.value.id, productForm.value)
        ElMessage.success('产品更新成功')
        loadAuditLogs(selectedProduct.value.id)
      } catch (error) {
        ElMessage.error('更新产品失败')
      }
    }

    // 选择产品
    const selectProduct = (product) => {
      selectedProduct.value = product
      productForm.value = { ...product }
      productDialogVisible.value = false
      loadAuditLogs(product.id)
    }

    // 显示产品列表
    const showProductList = () => {
      productDialogVisible.value = true
    }

    // 重置表单
    const resetForm = () => {
      productForm.value = {
        id: null,
        name: '',
        description: '',
        price: 0,
        stockQuantity: 0,
        internalCode: '',
        lastPrice: 0,
        supplierInfo: '',
        isActive: true
      }
    }

    // 刷新审计记录
    const refreshAuditLogs = () => {
      if (selectedProduct.value) {
        loadAuditLogs(selectedProduct.value.id)
      }
    }

    // 工具函数
    const getActionType = (action) => {
      const types = {
        'INSERT': 'success',
        'UPDATE': 'warning',
        'DELETE': 'danger'
      }
      return types[action] || 'info'
    }

    const getActionText = (action) => {
      const texts = {
        'INSERT': '新增',
        'UPDATE': '修改',
        'DELETE': '删除'
      }
      return texts[action] || action
    }

    const formatTime = (timestamp) => {
      return new Date(timestamp).toLocaleString('zh-CN')
    }

    const getPropertyName = (property) => {
      const names = {
        'name': '产品名称',
        'description': '描述',
        'price': '价格',
        'stockQuantity': '库存',
        'isActive': '状态',
        'internalCode': '内部编码',
        'lastPrice': '上次价格',
        'supplierInfo': '供应商信息'
      }
      return names[property] || property
    }

    onMounted(() => {
      loadProducts()
    })

    return {
      ignoredProperties,
      products,
      selectedProduct,
      auditLogs,
      auditLoading,
      productDialogVisible,
      productForm,
      Refresh,
      handleCreate,
      handleUpdate,
      selectProduct,
      showProductList,
      resetForm,
      refreshAuditLogs,
      getActionType,
      getActionText,
      formatTime,
      getPropertyName
    }
  }
}
</script>

<style scoped>
.audit-demo {
  padding: 20px;
}

.config-card {
  margin-bottom: 20px;
}

.config-info h3 {
  margin-top: 0;
  color: #333;
}

.ignored-properties {
  display: flex;
  gap: 10px;
  margin: 10px 0;
}

.property-tag {
  font-size: 14px;
}

.config-description {
  color: #666;
  font-style: italic;
}

.demo-section {
  margin-top: 20px;
}

.operation-card, .audit-result-card {
  height: 600px;
}

.ignore-note {
  font-size: 12px;
  color: #f56c6c;
  margin-left: 10px;
}

.operation-buttons {
  display: flex;
  gap: 10px;
  justify-content: center;
  margin-top: 20px;
}

.product-info {
  background: #f5f7fa;
  padding: 15px;
  border-radius: 4px;
  margin-bottom: 15px;
}

.empty-state {
  height: 400px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.audit-comparison {
  height: 500px;
  overflow-y: auto;
}

.audit-item {
  border: 1px solid #e6e6e6;
  border-radius: 6px;
  padding: 15px;
  margin-bottom: 15px;
  background: white;
}

.audit-header {
  display: flex;
  align-items: center;
  gap: 15px;
  margin-bottom: 15px;
}

.timestamp {
  color: #666;
  font-size: 14px;
}

.user {
  color: #999;
  font-size: 14px;
}

.changes-section, .ignored-section {
  margin-bottom: 15px;
}

.changes-section h4, .ignored-section h4 {
  margin: 0 0 10px 0;
  color: #333;
  font-size: 14px;
}

.tracked-changes, .ignored-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.change-item {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
  padding: 5px;
  border-radius: 3px;
}

.change-item.tracked {
  background: #f0f9eb;
}

.property-name {
  font-weight: 500;
  min-width: 100px;
}

.property-name.ignored {
  color: #999;
}

.old-value {
  color: #f56c6c;
  text-decoration: line-through;
}

.new-value {
  color: #67c23a;
}

.arrow {
  color: #909399;
}

.ignored-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 5px;
  background: #f5f5f5;
  border-radius: 3px;
}

.ignored-badge {
  background: #909399;
  color: white;
  padding: 2px 6px;
  border-radius: 3px;
  font-size: 12px;
}

.no-tracked-changes {
  color: #909399;
  font-style: italic;
  padding: 10px;
  text-align: center;
}
</style>