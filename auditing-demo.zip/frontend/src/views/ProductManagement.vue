<template>
  <div class="product-management">
    <el-container class="management-container">
      <!-- 左侧编辑区域 -->
      <el-aside width="60%" class="edit-panel">
        <div class="panel-header">
          <h2>产品管理</h2>
          <el-button type="primary" @click="handleAddProduct" :icon="Plus">
            新增产品
          </el-button>
        </div>
        
        <!-- 产品列表 -->
        <el-table :data="products" style="width: 100%" height="calc(100vh - 200px)">
          <el-table-column prop="id" label="ID" width="80" />
          <el-table-column prop="name" label="产品名称" />
          <el-table-column prop="price" label="价格" width="120">
            <template #default="{ row }">
              ¥{{ row.price }}
            </template>
          </el-table-column>
          <el-table-column prop="stockQuantity" label="库存" width="100" />
          <el-table-column prop="isActive" label="状态" width="100">
            <template #default="{ row }">
              <el-tag :type="row.isActive ? 'success' : 'danger'">
                {{ row.isActive ? '启用' : '禁用' }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column label="操作" width="200">
            <template #default="{ row }">
              <el-button size="small" @click="handleEdit(row)">编辑</el-button>
              <el-button size="small" type="primary" @click="handleViewAudit(row)">
                查看审计
              </el-button>
              <el-button size="small" type="danger" @click="handleDelete(row)">
                删除
              </el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-aside>

      <!-- 右侧审计抽屉 -->
      <el-main class="audit-panel">
        <div class="panel-header">
          <h2>审计记录</h2>
          <el-button @click="refreshAuditLogs" :icon="Refresh">
            刷新
          </el-button>
        </div>
        
        <!-- 审计记录列表 -->
        <div class="audit-list" v-loading="auditLoading">
          <div v-if="selectedProduct" class="selected-product-info">
            <h3>当前选择: {{ selectedProduct.name }}</h3>
            <p>ID: {{ selectedProduct.id }}</p>
          </div>
          
          <div v-if="!selectedProduct" class="empty-state">
            <el-empty description="请选择左侧的产品以查看审计记录" />
          </div>
          
          <div v-else-if="auditLogs.length === 0" class="empty-state">
            <el-empty description="暂无审计记录" />
          </div>
          
          <div v-else class="audit-items">
            <div v-for="log in auditLogs" :key="log.id" class="audit-item">
              <div class="audit-header">
                <span class="action-badge" :class="getActionClass(log.action)">
                  {{ getActionText(log.action) }}
                </span>
                <span class="timestamp">{{ formatTime(log.timestamp) }}</span>
                <span class="user">操作人: {{ log.userName }}</span>
              </div>
              
              <div class="changes-list" v-if="log.changes && log.changes.length > 0">
                <div v-for="change in log.changes" :key="change.propertyName" class="change-item">
                  <span class="property-name">{{ getPropertyName(change.propertyName) }}:</span>
                  <span class="old-value" v-if="change.oldValue !== null && change.oldValue !== undefined">
                    {{ change.oldValue }}
                  </span>
                  <span class="arrow" v-if="change.oldValue !== null && change.newValue !== null">→</span>
                  <span class="new-value" v-if="change.newValue !== null && change.newValue !== undefined">
                    {{ change.newValue }}
                  </span>
                </div>
              </div>
              
              <div v-else class="no-changes">
                <span v-if="log.action === 'INSERT'">创建了新记录</span>
                <span v-else-if="log.action === 'DELETE'">删除了记录</span>
                <span v-else>无具体变更</span>
              </div>
            </div>
          </div>
        </div>
      </el-main>
    </el-container>

    <!-- 产品编辑对话框 -->
    <el-dialog 
      v-model="dialogVisible" 
      :title="isEditing ? '编辑产品' : '新增产品'"
      width="500px"
    >
      <el-form :model="form" label-width="80px">
        <el-form-item label="产品名称">
          <el-input v-model="form.name" />
        </el-form-item>
        <el-form-item label="描述">
          <el-input v-model="form.description" type="textarea" :rows="3" />
        </el-form-item>
        <el-form-item label="价格">
          <el-input-number v-model="form.price" :min="0" :precision="2" />
        </el-form-item>
        <el-form-item label="库存">
          <el-input-number v-model="form.stockQuantity" :min="0" />
        </el-form-item>
        <el-form-item label="状态">
          <el-switch v-model="form.isActive" />
        </el-form-item>
      </el-form>
      
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="handleSubmit">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script>
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus, Refresh } from '@element-plus/icons-vue'
import api from '../services/api'

export default {
  name: 'ProductManagement',
  components: {
    Plus,
    Refresh
  },
  setup() {
    const products = ref([])
    const auditLogs = ref([])
    const selectedProduct = ref(null)
    const dialogVisible = ref(false)
    const isEditing = ref(false)
    const auditLoading = ref(false)
    
    const form = ref({
      id: 0,
      name: '',
      description: '',
      price: 0,
      stockQuantity: 0,
      isActive: true,
      internalCode: '',
      lastPrice: null,
      supplierInfo: ''
    })

    // 加载产品列表
    const loadProducts = async () => {
      try {
        const response = await api.getProducts()
        products.value = response.data
      } catch (error) {
        ElMessage.error('加载产品列表失败')
      }
    }

    // 加载审计记录
    const loadAuditLogs = async (productId) => {
      if (!productId) return
      
      auditLoading.value = true
      try {
        const response = await api.getEntityAuditLogs(productId.toString())
        auditLogs.value = response.data
      } catch (error) {
        ElMessage.error('加载审计记录失败')
      } finally {
        auditLoading.value = false
      }
    }

    // 处理操作
    const handleAddProduct = () => {
      isEditing.value = false
      form.value = {
        id: 0,
        name: '',
        description: '',
        price: 0,
        stockQuantity: 0,
        isActive: true,
        internalCode: '',
        lastPrice: null,
        supplierInfo: ''
      }
      dialogVisible.value = true
    }

    const handleEdit = (product) => {
      isEditing.value = true
      form.value = { ...product }
      dialogVisible.value = true
    }

    const handleViewAudit = (product) => {
      selectedProduct.value = product
      loadAuditLogs(product.id)
    }

    const handleDelete = async (product) => {
      try {
        await ElMessageBox.confirm(
          `确定要删除产品"${product.name}"吗？`,
          '确认删除',
          { type: 'warning' }
        )
        
        await api.deleteProduct(product.id)
        ElMessage.success('删除成功')
        loadProducts()
        
        // 如果删除的是当前查看的产品，清空审计记录
        if (selectedProduct.value && selectedProduct.value.id === product.id) {
          selectedProduct.value = null
          auditLogs.value = []
        }
      } catch (error) {
        if (error !== 'cancel') {
          ElMessage.error('删除失败')
        }
      }
    }

    const handleSubmit = async () => {
      try {
        if (isEditing.value) {
          await api.updateProduct(form.value.id, form.value)
          ElMessage.success('更新成功')
        } else {
          await api.createProduct(form.value)
          ElMessage.success('创建成功')
        }
        
        dialogVisible.value = false
        loadProducts()
      } catch (error) {
        ElMessage.error(isEditing.value ? '更新失败' : '创建失败')
      }
    }

    const refreshAuditLogs = () => {
      if (selectedProduct.value) {
        loadAuditLogs(selectedProduct.value.id)
      }
    }

    // 工具函数
    const getActionClass = (action) => {
      const classes = {
        'INSERT': 'success',
        'UPDATE': 'warning',
        'DELETE': 'danger'
      }
      return classes[action] || 'info'
    }

    const getActionText = (action) => {
      const texts = {
        'INSERT': '新增',
        'UPDATE': '修改',
        'DELETE': '删除'
      }
      return texts[action] || action
    }

    const formatTime = (timestamp) => {
      return new Date(timestamp).toLocaleString('zh-CN')
    }

    const getPropertyName = (property) => {
      const names = {
        'name': '产品名称',
        'description': '描述',
        'price': '价格',
        'stockQuantity': '库存',
        'isActive': '状态'
      }
      return names[property] || property
    }

    onMounted(() => {
      loadProducts()
    })

    return {
      products,
      auditLogs,
      selectedProduct,
      dialogVisible,
      isEditing,
      auditLoading,
      form,
      Plus,
      Refresh,
      handleAddProduct,
      handleEdit,
      handleViewAudit,
      handleDelete,
      handleSubmit,
      refreshAuditLogs,
      getActionClass,
      getActionText,
      formatTime,
      getPropertyName
    }
  }
}
</script>

<style scoped>
.product-management {
  height: 100%;
}

.management-container {
  height: 100%;
}

.edit-panel, .audit-panel {
  padding: 20px;
  border-right: 1px solid #e6e6e6;
  height: 100%;
  overflow: auto;
}

.audit-panel {
  border-right: none;
}

.panel-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.panel-header h2 {
  margin: 0;
  color: #333;
}

.audit-list {
  height: calc(100vh - 200px);
  overflow-y: auto;
}

.selected-product-info {
  background: #f5f7fa;
  padding: 15px;
  border-radius: 4px;
  margin-bottom: 20px;
}

.selected-product-info h3 {
  margin: 0 0 5px 0;
  color: #333;
}

.selected-product-info p {
  margin: 0;
  color: #666;
}

.empty-state {
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
}

.audit-items {
  display: flex;
  flex-direction: column;
  gap: 15px;
}

.audit-item {
  border: 1px solid #e6e6e6;
  border-radius: 6px;
  padding: 15px;
  background: white;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}

.audit-header {
  display: flex;
  align-items: center;
  gap: 15px;
  margin-bottom: 10px;
}

.action-badge {
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 12px;
  font-weight: bold;
  color: white;
}

.action-badge.success { background: #67c23a; }
.action-badge.warning { background: #e6a23c; }
.action-badge.danger { background: #f56c6c; }
.action-badge.info { background: #909399; }

.timestamp {
  color: #666;
  font-size: 14px;
}

.user {
  color: #999;
  font-size: 14px;
}

.changes-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.change-item {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
}

.property-name {
  font-weight: 500;
  color: #333;
  min-width: 80px;
}

.old-value {
  color: #f56c6c;
  text-decoration: line-through;
  background: #fef0f0;
  padding: 2px 6px;
  border-radius: 3px;
}

.new-value {
  color: #67c23a;
  background: #f0f9eb;
  padding: 2px 6px;
  border-radius: 3px;
}

.arrow {
  color: #909399;
}

.no-changes {
  color: #909399;
  font-style: italic;
}
</style>