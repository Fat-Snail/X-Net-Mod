#!/bin/bash
echo "正在关闭占用5100端口的进程..."
PIDS=$(lsof -ti:5100)
if [ -n "$PIDS" ]; then
    echo "找到进程: $PIDS"
    echo $PIDS | xargs kill -9
    echo "进程已关闭"
else
    echo "没有找到占用5100端口的进程"
fi