using System.Net.Http;
using System.Text.Json;
using System.Text.Json.Nodes;

namespace SemanticKernelExample
{
    /// <summary>
    /// Ollama连接诊断工具
    /// 帮助检测Ollama服务器连接问题
    /// </summary>
    public class OllamaDiagnostic
    {
        private const string OllamaBaseUrl = "http://localhost:11434";
        
        public static async Task RunAsync()
        {
            Console.WriteLine("Ollama 连接诊断");
            Console.WriteLine("==================\n");

            // 检查Ollama服务器是否运行
            await CheckOllamaHealth();
            
            // 列出可用模型
            await ListAvailableModels();
            
            Console.WriteLine("\n诊断完成！根据诊断结果，请相应地更新您的连接配置。");
        }

        /// <summary>
        /// 检查Ollama服务器健康状况
        /// </summary>
        private static async Task CheckOllamaHealth()
        {
            try
            {
                using var httpClient = new HttpClient();
                httpClient.Timeout = TimeSpan.FromSeconds(10);

                var response = await httpClient.GetAsync($"{OllamaBaseUrl}/api/tags");
                
                if (response.IsSuccessStatusCode)
                {
                    Console.WriteLine("✅ Ollama服务器连接正常");
                    
                    var jsonResponse = await response.Content.ReadAsStringAsync();
                    var jsonDoc = JsonDocument.Parse(jsonResponse);
                    
                    if (jsonDoc.RootElement.TryGetProperty("models", out var modelsElement))
                    {
                        var modelCount = modelsElement.GetArrayLength();
                        Console.WriteLine($"✅ 找到 {modelCount} 个模型");
                        
                        if (modelCount > 0)
                        {
                            Console.WriteLine("   可用模型列表:");
                            foreach (var model in modelsElement.EnumerateArray())
                            {
                                if (model.TryGetProperty("name", out var nameElement))
                                {
                                    Console.WriteLine($"   - {nameElement.GetString()}");
                                }
                            }
                        }
                    }
                }
                else
                {
                    Console.WriteLine($"❌ Ollama服务器连接失败 - HTTP {(int)response.StatusCode} {response.StatusCode}");
                    Console.WriteLine($"   请确认Ollama服务是否正在运行在 {OllamaBaseUrl}");
                }
            }
            catch (HttpRequestException hex)
            {
                Console.WriteLine($"❌ HTTP请求错误: {hex.Message}");
                Console.WriteLine($"   请确认Ollama服务是否正在运行在 {OllamaBaseUrl}");
            }
            catch (TaskCanceledException)
            {
                Console.WriteLine($"❌ 请求超时 - 请确认Ollama服务是否正在运行在 {OllamaBaseUrl}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ 连接错误: {ex.Message}");
            }
        }

        /// <summary>
        /// 列出可用模型
        /// </summary>
        private static async Task ListAvailableModels()
        {
            try
            {
                using var httpClient = new HttpClient();
                httpClient.Timeout = TimeSpan.FromSeconds(10);

                var response = await httpClient.GetAsync($"{OllamaBaseUrl}/api/tags");
                
                if (response.IsSuccessStatusCode)
                {
                    var jsonResponse = await response.Content.ReadAsStringAsync();
                    var jsonObject = JsonNode.Parse(jsonResponse);
                    
                    var models = jsonObject?["models"];
                    if (models != null && models.AsArray().Any())
                    {
                        Console.WriteLine("\n💡 以下是可以使用的模型名称（用于Semantic Kernel配置）:");
                        
                        foreach (var model in models.AsArray())
                        {
                            var name = model?["name"]?.ToString();
                            var digest = model?["digest"]?.ToString();
                            
                            if (!string.IsNullOrEmpty(name))
                            {
                                // 显示模型名称的几种可能格式
                                Console.WriteLine($"   • ModelId: \"{name}\"");
                                
                                // 如果名称包含冒号，提供简化版本
                                if (name.Contains(':'))
                                {
                                    var simpleName = name.Split(':')[0];
                                    Console.WriteLine($"   • Alternative: \"{simpleName}\" (如果遇到问题可尝试)");
                                }
                            }
                        }
                        
                        Console.WriteLine("\n🔧 建议的Semantic Kernel配置:");
                        Console.WriteLine($"   builder.AddOpenAIChatCompletion(");
                        Console.WriteLine($"       modelId: \"<选择上面列出的模型名称>\",");
                        Console.WriteLine($"       apiKey: \"\",  // Ollama不需要API密钥");
                        Console.WriteLine($"       endpoint: new Uri(\"{OllamaBaseUrl}\")");
                        Console.WriteLine($"   );");
                    }
                    else
                    {
                        Console.WriteLine("\n💡 没有找到任何模型");
                        Console.WriteLine("   请使用 'ollama pull <model_name>' 下载模型，例如:");
                        Console.WriteLine("   - ollama pull llama3.2");
                        Console.WriteLine("   - ollama pull mistral");
                        Console.WriteLine("   - ollama pull phi3");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"\n❌ 获取模型列表失败: {ex.Message}");
            }
        }
    }
}