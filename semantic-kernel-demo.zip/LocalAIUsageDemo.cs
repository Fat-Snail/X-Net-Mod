using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.Plugins.Core;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.SemanticKernel.Connectors.OpenAI;

#pragma warning disable SKEXP0050
namespace SemanticKernelExample
{
    /// <summary>
    /// 本地AI模型使用演示
    /// 此类展示如何实际连接和使用本地AI模型
    /// </summary>
    public class LocalAIUsageDemo
    {
        public static async Task RunAsync()
        {
            Console.WriteLine("=");
            Console.WriteLine("本地AI模型实际使用演示");
            Console.WriteLine("================================\n");

            Console.WriteLine("注意：要运行此演示，您需要：");
            Console.WriteLine("1. 启动本地AI服务器（如Ollama）");
            Console.WriteLine("2. 运行命令: ollama serve");
            Console.WriteLine("3. 下载模型: ollama pull llama3.2:3b");
            Console.WriteLine("4. 然后取消注释下面的相关代码\n");

            // 演示如何连接到本地AI服务
            await DemoConnectionToOllama();
            
            Console.WriteLine("本地AI模型使用演示完成！");
        }

        /// <summary>
        /// 演示连接到Ollama本地AI服务器
        /// </summary>
        private static async Task DemoConnectionToOllama()
        {
            try
            {
                // 检查本地服务器是否可用
                bool isServerAvailable = await IsLocalAIServerAvailable();
                
                if (!isServerAvailable)
                {
                    Console.WriteLine("⚠️  本地AI服务器未运行");
                    Console.WriteLine("   请先启动本地AI服务器（如Ollama）");
                    Console.WriteLine("   示例命令: ollama serve\n");
                    return;
                }

                Console.WriteLine("✅ 本地AI服务器可用，创建Kernel实例...\n");

                // 创建连接到本地AI服务的Kernel
                var builder = Kernel.CreateBuilder();
                
                // 添加日志服务
                builder.Services.AddLogging(c => c.AddConsole().SetMinimumLevel(LogLevel.Information));

                // 添加核心插件
                builder.Plugins.AddFromType<TimePlugin>("Time");
                builder.Plugins.AddFromType<MathPlugin>("Math");

                // 连接到本地Ollama服务器
                // 使用兼容OpenAI API的配置
                builder.AddOpenAIChatCompletion(
                    modelId: "llama3.2:3b",  // 使用诊断工具确认的模型名称
                    apiKey: "ollama",       // Ollama使用占位符密钥
                    endpoint: new Uri("http://localhost:11434/v1")  // Ollama兼容OpenAI API的端点
                );

                var kernel = builder.Build();

                Console.WriteLine("1. 成功连接到本地AI模型！\n");

                // 演示使用本地AI处理简单请求
                Console.WriteLine("2. 演示使用本地AI处理请求：");
                
                // 示例1: 简单的问答
                var simpleQuestion = "什么是人工智能？请用100字以内回答。";
                Console.WriteLine($"   问题: {simpleQuestion}");
                
                try
                {
                    var result = await kernel.InvokePromptAsync(simpleQuestion);
                    Console.WriteLine($"   本地AI回答: {result.GetValue<string>()}\n");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"   本地AI响应失败: {ex.Message}\n");
                }

                // 示例2: 结合插件功能
                Console.WriteLine("3. 演示结合插件功能：");
                
                var complexPrompt = @"
今天的日期是 {{Time.Date}}。
请根据今天的日期，用一句话表达对未来的期望。
";
                Console.WriteLine($"   复杂提示: {complexPrompt.Trim()}");
                
                try
                {
                    var complexResult = await kernel.InvokePromptAsync(complexPrompt);
                    Console.WriteLine($"   本地AI响应: {complexResult.GetValue<string>()}\n");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"   本地AI响应失败: {ex.Message}\n");
                }

                // 示例3: 使用函数调用
                Console.WriteLine("4. 演示函数调用结合AI处理：");
                
                // 先使用插件计算
                var calculationResult = await kernel.InvokeAsync<int>("Math", "Add", new() 
                { 
                    ["value"] = "10", 
                    ["amount"] = "20" 
                });
                
                Console.WriteLine($"   插件计算结果: 10 + 20 = {calculationResult}");
                
                // 然后让AI解释结果
                var explanationPrompt = $"请解释数字 {calculationResult} 在日常生活中的意义。";
                try
                {
                    var explanation = await kernel.InvokePromptAsync(explanationPrompt);
                    Console.WriteLine($"   本地AI解释: {explanation.GetValue<string>()}\n");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"   本地AI解释失败: {ex.Message}\n");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"连接本地AI服务失败: {ex.Message}");
                Console.WriteLine("请确保本地AI服务器正在运行并且配置正确。\n");
            }
        }

        /// <summary>
        /// 检查本地AI服务器是否可用
        /// </summary>
        private static async Task<bool> IsLocalAIServerAvailable()
        {
            try
            {
                // 这里可以添加实际的健康检查逻辑
                // 目前只是演示目的，实际应用中需要真正检查服务器连接
                using var httpClient = new HttpClient();
                httpClient.Timeout = TimeSpan.FromSeconds(5); // 设置超时
                
                // 尝试连接到本地Ollama服务器
                // var response = await httpClient.GetAsync("http://localhost:11434/api/tags");
                // return response.IsSuccessStatusCode;
                
                // 由于这只是演示，返回true以展示代码结构
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}