﻿using SemanticKernelExample;

// 运行基础示例
await BasicExample.RunAsync();

Console.WriteLine();

// 运行高级示例
await AdvancedExample.RunAsync();

Console.WriteLine();

// 运行本地AI模型演示
await LocalAIDemo.RunAsync();

Console.WriteLine();

// 运行本地AI使用演示
await LocalAIUsageDemo.RunAsync();

Console.WriteLine();

// 运行Ollama诊断
await OllamaDiagnostic.RunAsync();

// 保持控制台窗口打开
Console.ReadKey();
