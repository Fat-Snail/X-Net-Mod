using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.Plugins.Core;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.DependencyInjection;

namespace SemanticKernelExample
{
    public class AdvancedExample
    {
        public static async Task RunAsync()
        {
            Console.WriteLine("Semantic Kernel 高级功能示例");
            Console.WriteLine("==============================\n");

#pragma warning disable SKEXP0050
            // 创建Kernel实例
            var builder = Kernel.CreateBuilder();
            
            // 配置日志服务
            builder.Services.AddLogging(c => c.AddConsole().SetMinimumLevel(LogLevel.Information));
            
            // 添加内置插件
            builder.Plugins.AddFromType<TimePlugin>("Time");
            builder.Plugins.AddFromType<MathPlugin>("Math");
            
            // 构建Kernel实例
            var kernel = builder.Build();
#pragma warning restore SKEXP0050

            // 示例1：自定义Prompt函数
            Console.WriteLine("示例1: 自定义Prompt函数");
            Console.WriteLine("------------------------");
            Console.WriteLine("提示：此功能需要配置AI服务（如OpenAI、Azure OpenAI等）\n");

            // 示例2：使用管道执行多个函数
            Console.WriteLine("示例2: 函数管道执行");
            Console.WriteLine("--------------------");
            
            // 执行数学运算
            var mathResult = await kernel.InvokeAsync<int>(
                "Math", 
                "Add", 
                new() 
                { 
                    ["value"] = "5", 
                    ["amount"] = "7" 
                }
            );
            Console.WriteLine($"数学运算结果 (5 + 7): {mathResult}\n");

            // 示例3：注册自定义函数
            Console.WriteLine("示例3: 自定义函数");
            Console.WriteLine("------------------");
            
            // 定义一个自定义函数
            var customFunction = kernel.CreateFunctionFromMethod(() => 
            {
                return $"这是一个由Semantic Kernel执行的自定义函数，当前时间: {DateTime.Now}";
            }, "GetCurrentInfo", "返回当前时间和自定义信息");
            
            var plugin = KernelPluginFactory.CreateFromFunctions("CustomFunctions", "自定义函数集合", new[] { customFunction });
            kernel.Plugins.Add(plugin);
            
            var customResult = await kernel.InvokeAsync("CustomFunctions", "GetCurrentInfo");
            Console.WriteLine($"自定义函数结果: {customResult}\n");

            // 示例4：使用变量和上下文
            Console.WriteLine("示例4: 变量和上下文管理");
            Console.WriteLine("--------------------------");
            Console.WriteLine("提示：此功能需要配置AI服务（如OpenAI、Azure OpenAI等）\n");

            // 示例5：使用内置插件组合
            Console.WriteLine("示例5: 插件组合使用");
            Console.WriteLine("---------------------");
            
            Console.WriteLine("提示：此功能需要配置AI服务（如OpenAI、Azure OpenAI等）\n");

            Console.WriteLine("高级功能示例执行完成！");
        }
    }
}