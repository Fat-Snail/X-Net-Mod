using Microsoft.SemanticKernel;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.SemanticKernel.Plugins.Core;

namespace SemanticKernelExample
{
    public class BasicExample
    {
        public static async Task RunAsync()
        {
#pragma warning disable SKEXP0050
            // 创建Semantic Kernel实例
            var builder = Kernel.CreateBuilder();
            
            // 配置日志服务
            builder.Services.AddLogging(c => c.AddConsole().SetMinimumLevel(LogLevel.Information));
            
            // 添加内置插件
            builder.Plugins.AddFromType<TimePlugin>("Time");
            
            // 构建Kernel实例
            var kernel = builder.Build();
#pragma warning restore SKEXP0050

            // 输出欢迎信息
            Console.WriteLine("Semantic Kernel 基础示例");
            Console.WriteLine("========================\n");

            // 演示使用TimePlugin获取当前时间
            var timeResult = await kernel.InvokeAsync<string>("Time", "Date");
            Console.WriteLine($"当前日期: {timeResult}");

            // 提示：要使用Prompt功能，需要配置AI服务（如OpenAI、Azure OpenAI等）
            Console.WriteLine("提示：要使用Prompt功能，需要配置AI服务（如OpenAI、Azure OpenAI等）\n");

            Console.WriteLine("\n基础示例执行完成！");
        }
    }
}