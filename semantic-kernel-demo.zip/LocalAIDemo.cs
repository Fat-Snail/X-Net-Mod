#pragma warning disable SKEXP0050
using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.Plugins.Core;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.SemanticKernel.Connectors.OpenAI;
#pragma warning restore SKEXP0050

namespace SemanticKernelExample
{
    public class LocalAIDemo
    {
        public static async Task RunAsync()
        {
            Console.WriteLine("Semantic Kernel 本地AI模型演示");
            Console.WriteLine("================================\n");

            // 创建一个演示，展示如何连接到本地AI服务器
            Console.WriteLine("此演示展示如何配置Semantic Kernel以使用本地AI模型");
            Console.WriteLine("例如：使用Ollama、GPT4All、LocalAI或任何兼容OpenAI API的本地服务器\n");

            // 方式1: 使用Kernel创建器连接到本地OpenAI兼容服务器
            try
            {
                // 注意：要使用真正的本地模型，您需要：
                // 1. 启动一个兼容OpenAI API的本地服务器（如Ollama、llama.cpp的server模式等）
                // 2. 将下面的endpoint指向您的本地服务器
                var builder = Kernel.CreateBuilder();

                // 添加日志服务
                builder.Services.AddLogging(c => c.AddConsole().SetMinimumLevel(LogLevel.Information));

                // 添加核心插件
#pragma warning disable SKEXP0050
                builder.Plugins.AddFromType<TimePlugin>("Time");
                builder.Plugins.AddFromType<MathPlugin>("Math");
#pragma warning restore SKEXP0050

                // 注意：以下代码显示如何连接到本地AI模型
                // 您需要根据实际的本地服务器配置调整参数

                /*
                // 示例：连接到本地Ollama服务器
                builder.AddOpenAIChatCompletion(
                    modelId: "llama3.2:3b",  // 或其他本地模型名称
                    apiKey: "",  // 本地服务器通常不需要真实API密钥
                    endpoint: new Uri("http://localhost:11434")  // Ollama默认端口
                );
                */

                /*
                // 示例：连接到llama.cpp的server模式
                builder.AddOpenAIChatCompletion(
                    modelId: "ggml-model",  // 您的模型名称
                    apiKey: "",
                    endpoint: new Uri("http://localhost:8080")  // llama.cpp server端口
                );
                */

     

                var kernel = builder.Build();

                Console.WriteLine("1. 本地AI模型连接配置示例：");
                Console.WriteLine("   - 支持Ollama (http://localhost:11434)");
                Console.WriteLine("   - 支持llama.cpp server (http://localhost:8080)");
                Console.WriteLine("   - 支持LocalAI (http://localhost:8080)");
                Console.WriteLine("   - 支持任何兼容OpenAI API的本地服务器\n");

                // 演示现有插件功能（不需要AI模型）
                Console.WriteLine("2. 演示无需AI模型的插件功能：");
                
                // TimePlugin功能演示
                var timeResult = await kernel.InvokeAsync<string>("Time", "Date");
                Console.WriteLine($"   当前日期: {timeResult}");

                // MathPlugin功能演示
                var mathResult = await kernel.InvokeAsync<int>("Math", "Add", new() 
                { 
                    ["value"] = "15", 
                    ["amount"] = "25" 
                });
                Console.WriteLine($"   数学运算 (15 + 25): {mathResult}\n");

                // 演示如何创建可与本地AI一起使用的Prompt
                Console.WriteLine("3. 为本地AI准备的Prompt示例：");
                
                // 创建一个可以发送到本地AI的提示
                var demoPrompt = @"今天的日期是 {{Time.Date}}。
请用一句话概括今天的重要性或特殊之处。
当前时间: {{Time.Now}}";

                Console.WriteLine($"   提示内容: {demoPrompt}\n");

                // 演示自定义函数
                Console.WriteLine("4. 自定义函数示例：");
                var customFunction = kernel.CreateFunctionFromMethod(() => 
                {
                    return $"本地AI演示函数执行于: {DateTime.Now}";
                }, "LocalAIDemoFunction", "用于演示本地AI集成的自定义函数");

                var customResult = await kernel.InvokeAsync<string>(customFunction);
                Console.WriteLine($"   自定义函数结果: {customResult}\n");

                Console.WriteLine("5. 如何使用本地AI模型：");
                Console.WriteLine("   a) 启动本地AI服务器（如Ollama）");
                Console.WriteLine("   b) 修改代码以连接到本地服务器");
                Console.WriteLine("   c) 使用InvokePromptAsync等方法调用本地模型\n");

                Console.WriteLine("要实际运行本地AI功能，请：");
                Console.WriteLine("1. 安装Ollama (https://ollama.ai/) 或其他本地AI服务器");
                Console.WriteLine("2. 下载模型: ollama pull llama3.2:3b");
                Console.WriteLine("3. 启动服务器: ollama serve");
                Console.WriteLine("4. 更新代码以连接到 http://localhost:11434");
                Console.WriteLine("5. 取消注释上面的AddOpenAIChatCompletion代码\n");

                // 如果本地AI服务可用，演示实际调用
                try
                {
                    Console.WriteLine("6. 实际的本地AI调用示例：");
                    
                    // 演示使用本地AI的Prompt功能
                    var prompt = "请用一句话介绍什么是机器学习。";
                    Console.WriteLine($"   发送给本地AI的提示: {prompt}");
                    
                    // 注意：只有当本地AI服务可用时，以下代码才会执行成功
                    // var aiResult = await kernel.InvokePromptAsync(prompt);
                    // Console.WriteLine($"   本地AI响应: {aiResult.GetValue<string>()}");
                    
                    Console.WriteLine("   （实际调用需要本地AI服务正在运行）\n");
                }
                catch (Exception aiEx)
                {
                    Console.WriteLine($"   本地AI调用失败 (这很正常，如果没有运行本地AI服务): {aiEx.Message}\n");
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine($"演示过程中出现错误: {ex.Message}");
            }

            Console.WriteLine("本地AI模型演示完成！");
        }
    }
}